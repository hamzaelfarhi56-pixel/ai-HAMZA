import { useState } from "react";
import { ArrowRight, Clapperboard, Film, Layers, Plus, Search, Trash2, Users, X } from "lucide-react";
import type { User } from "firebase/auth";
import {
  SHOWCASE_TEMPLATES,
  VISUAL_STYLES,
  type AspectRatio,
  type ShowcaseTemplate,
  type StudioProject,
  type UserProfile,
} from "../types/studio";
import { SafeMediaImage } from "./MediaFallback";

interface HomePageProps {
  user: User | null;
  profile: UserProfile | null;
  projects: StudioProject[];
  loadingProjects: boolean;
  onSignIn: () => void;
  onOpenProject: (projectId: string) => void;
  onCreateProject: (data: {
    title: string;
    synopsis: string;
    genre: string;
    visualStyle: string;
    aspectRatio: AspectRatio;
  }) => Promise<void>;
  onCreateFromTemplate: (template: ShowcaseTemplate) => Promise<void>;
  onDeleteProject: (projectId: string) => Promise<void>;
}

export function HomePage({
  user,
  profile,
  projects,
  loadingProjects,
  onSignIn,
  onOpenProject,
  onCreateProject,
  onCreateFromTemplate,
  onDeleteProject,
}: HomePageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [genre, setGenre] = useState("Sci-Fi Drama");
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>(
    profile?.defaultAspectRatio || "16:9"
  );
  const [visualStyle, setVisualStyle] = useState<string>(
    profile?.defaultStyle || VISUAL_STYLES[0]
  );
  const [synopsis, setSynopsis] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [templateLoadingId, setTemplateLoadingId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const filteredProjects = projects.filter((p) => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      p.title.toLowerCase().includes(q) ||
      (p.genre || "").toLowerCase().includes(q) ||
      (p.synopsis || "").toLowerCase().includes(q)
    );
  });

  async function handleCreateSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setSubmitting(true);
    setErrorMsg(null);
    try {
      await onCreateProject({
        title: title.trim(),
        synopsis: synopsis.trim(),
        genre: genre.trim() || "Cinema",
        visualStyle,
        aspectRatio,
      });
      setTitle("");
      setSynopsis("");
      setModalOpen(false);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Could not create project.");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleLaunchTemplate(tpl: ShowcaseTemplate) {
    if (!user) {
      onSignIn();
      return;
    }
    setTemplateLoadingId(tpl.id);
    setErrorMsg(null);
    try {
      await onCreateFromTemplate(tpl);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Could not load template project.");
    } finally {
      setTemplateLoadingId(null);
    }
  }

  // Signed-Out Cinematic Showcase Landing
  if (!user) {
    return (
      <main className="max-w-[1440px] mx-auto px-4 sm:px-6 py-10 sm:py-16 space-y-16">
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
            <h1 className="text-3xl sm:text-5xl font-semibold tracking-tight text-[#F2F4F8] font-display leading-[1.1] [text-wrap:balance]">
              Direct coherent AI cinema from first script to final cut.
            </h1>
            <p className="text-base text-neutral-300 leading-relaxed max-w-xl">
              Organize characters, visual references, storyboard scenes, and AI-generated video
              clips inside unified studio projects. Move seamlessly from text prompts and keyframe
              motion to a multi-clip timeline export.
            </p>
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                type="button"
                onClick={onSignIn}
                className="px-6 py-3 text-sm font-semibold rounded-lg bg-[#E59F3E] text-[#0B0D10] hover:bg-[#F0AE52] transition-colors inline-flex items-center gap-2 cursor-pointer"
              >
                <span>Sign In to Open Studio</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <span className="text-xs text-neutral-400">
                Includes 250 starter studio credits on sign-in
              </span>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="relative aspect-video lg:h-full rounded-xl overflow-hidden border border-white/10 bg-[#12151B]">
              <SafeMediaImage
                src="/src/assets/images/studio_scifi_noir_1795353163965.jpg"
                alt="Rain-slicked futuristic alley film frame"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 via-black/45 to-transparent p-6">
                <p className="text-xs text-neutral-300 mb-1">
                  Anamorphic 35mm · 16:9 · Scene 01
                </p>
                <p className="text-base font-semibold text-white font-display">
                  Meridian Rain — Visual Continuity Showcase
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-4 gap-6 pt-8 border-t border-white/8">
          <div className="space-y-2">
            <Film className="w-5 h-5 text-[#E59F3E]" />
            <h2 className="text-sm font-semibold text-[#F2F4F8] font-display">
              Multi-Modal Video Engine
            </h2>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Generate from text, animate static frames, or guide motion between start and end
              keyframes with camera and duration controls.
            </p>
          </div>
          <div className="space-y-2">
            <Users className="w-5 h-5 text-[#E59F3E]" />
            <h2 className="text-sm font-semibold text-[#F2F4F8] font-display">
              Character Consistency Bible
            </h2>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Define characters, props, and locations once and bind them across every storyboard
              prompt and video generation.
            </p>
          </div>
          <div className="space-y-2">
            <Layers className="w-5 h-5 text-[#E59F3E]" />
            <h2 className="text-sm font-semibold text-[#F2F4F8] font-display">
              Dedicated Storyboard
            </h2>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Break ideas into ordered scenes with AI assistance, track generation progress, and
              iterate frame by frame.
            </p>
          </div>
          <div className="space-y-2">
            <Clapperboard className="w-5 h-5 text-[#E59F3E]" />
            <h2 className="text-sm font-semibold text-[#F2F4F8] font-display">
              Scene Builder Timeline
            </h2>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Arrange clips, trim in/out points, apply transitions, preview the assembled story, and
              export your final movie.
            </p>
          </div>
        </section>

        <section className="space-y-5 pt-4 border-t border-white/8">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-[#F2F4F8] font-display">
              Starter Studio Projects
            </h2>
            <span className="text-xs text-neutral-400">Sign in to clone into your workspace</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {SHOWCASE_TEMPLATES.map((tpl) => (
              <div
                key={tpl.id}
                className="bg-[#12151B] border border-white/8 rounded-xl overflow-hidden flex flex-col"
              >
                <div className="aspect-video bg-[#0B0D10] overflow-hidden">
                  <SafeMediaImage src={tpl.thumbnailUrl} alt={tpl.title} />
                </div>
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-1.5">
                    <p className="text-xs text-neutral-400">
                      {tpl.genre} · {tpl.visualStyle} · {tpl.aspectRatio}
                    </p>
                    <h3 className="text-base font-semibold text-[#F2F4F8] font-display">
                      {tpl.title}
                    </h3>
                    <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                      {tpl.synopsis}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => void handleLaunchTemplate(tpl)}
                    className="w-full py-2 px-4 text-xs font-medium rounded-lg border border-white/12 text-[#F2F4F8] hover:border-[#E59F3E] hover:text-[#E59F3E] transition-colors cursor-pointer"
                  >
                    Sign In to Use Template
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    );
  }

  return (
    <main className="max-w-[1440px] mx-auto px-4 sm:px-6 py-8 space-y-10">
      {/* Studio Workspace Header & Controls */}
      <section className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 pb-6 border-b border-white/8">
        <div className="space-y-1.5">
          <p className="text-xs text-neutral-400">
            Production Library ·{" "}
            <span className="font-mono tabular-nums text-[#E59F3E]">
              {profile?.credits ?? 0} credits remaining
            </span>
          </p>
          <h1 className="text-2xl sm:text-3xl font-semibold text-[#F2F4F8] font-display tracking-tight">
            Your Studio Projects
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search projects..."
              className="pl-9 pr-3 py-2 text-xs bg-[#12151B] border border-white/10 rounded-lg text-[#F2F4F8] placeholder:text-neutral-500 focus:outline-none focus:border-[#E59F3E] w-48 sm:w-60"
            />
          </div>
          <button
            type="button"
            onClick={() => setModalOpen(true)}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#E59F3E] text-[#0B0D10] hover:bg-[#F0AE52] transition-colors inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Project</span>
          </button>
        </div>
      </section>

      {errorMsg && (
        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-300 flex items-center justify-between gap-4">
          <span>{errorMsg}</span>
          <button
            type="button"
            onClick={() => setErrorMsg(null)}
            className="text-red-300 hover:text-white cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* User Projects Grid */}
      <section className="space-y-4">
        {loadingProjects ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((n) => (
              <div
                key={n}
                className="bg-[#12151B] border border-white/8 rounded-xl overflow-hidden animate-pulse"
              >
                <div className="aspect-video bg-[#181C24]" />
                <div className="p-5 space-y-3">
                  <div className="h-3 w-32 bg-[#181C24] rounded" />
                  <div className="h-5 w-48 bg-[#181C24] rounded" />
                  <div className="h-3 w-full bg-[#181C24] rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredProjects.length === 0 ? (
          <div className="bg-[#12151B] border border-white/8 rounded-xl p-10 text-center space-y-4">
            <Film className="w-8 h-8 text-neutral-500 mx-auto" />
            <div className="space-y-1 max-w-md mx-auto">
              <h2 className="text-base font-semibold text-[#F2F4F8] font-display">
                {searchQuery ? "No matching projects" : "No projects yet"}
              </h2>
              <p className="text-xs text-neutral-400 leading-relaxed">
                {searchQuery
                  ? "Try clearing your search filter or create a fresh production project."
                  : "Create a blank studio project or start from one of the curated templates below."}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setModalOpen(true)}
              className="px-5 py-2.5 text-xs font-semibold rounded-lg bg-[#E59F3E] text-[#0B0D10] hover:bg-[#F0AE52] transition-colors inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Project</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project) => (
              <div
                key={project.id}
                className="group bg-[#12151B] border border-white/8 hover:border-white/20 rounded-xl overflow-hidden flex flex-col transition-colors"
              >
                <button
                  type="button"
                  onClick={() => onOpenProject(project.id)}
                  className="aspect-video bg-[#0B0D10] overflow-hidden relative block w-full text-left cursor-pointer"
                >
                  <SafeMediaImage src={project.thumbnailUrl} alt={project.title} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-80 group-hover:opacity-95 transition-opacity" />
                </button>

                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-1.5">
                    <p className="text-xs text-neutral-400 font-mono tabular-nums">
                      {project.aspectRatio} · {project.visualStyle} · {project.sceneCount} scenes ·{" "}
                      {project.assetCount} assets
                    </p>
                    <h3 className="text-base font-semibold text-[#F2F4F8] font-display truncate">
                      {project.title}
                    </h3>
                    {project.synopsis && (
                      <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                        {project.synopsis}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center justify-between gap-3 pt-2 border-t border-white/6">
                    <button
                      type="button"
                      onClick={() => onOpenProject(project.id)}
                      className="text-xs font-semibold text-[#E59F3E] hover:text-[#F0AE52] inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>Open Workspace</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      aria-label={`Delete ${project.title}`}
                      onClick={() => void onDeleteProject(project.id)}
                      className="p-1.5 text-neutral-500 hover:text-red-400 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Starter Cinema Templates */}
      <section className="space-y-4 pt-6 border-t border-white/8">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-[#F2F4F8] font-display">
              Quick-Start Cinema Templates
            </h2>
            <p className="text-xs text-neutral-400">
              Launch a pre-configured project with character references and initial storyboard
              scenes.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {SHOWCASE_TEMPLATES.map((tpl) => {
            const busy = templateLoadingId === tpl.id;
            return (
              <div
                key={tpl.id}
                className="bg-[#12151B] border border-white/8 rounded-xl overflow-hidden flex flex-col"
              >
                <div className="aspect-video bg-[#0B0D10] overflow-hidden">
                  <SafeMediaImage src={tpl.thumbnailUrl} alt={tpl.title} />
                </div>
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-1.5">
                    <p className="text-xs text-neutral-400">
                      {tpl.genre} · {tpl.visualStyle} · {tpl.aspectRatio}
                    </p>
                    <h3 className="text-base font-semibold text-[#F2F4F8] font-display">
                      {tpl.title}
                    </h3>
                    <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                      {tpl.synopsis}
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void handleLaunchTemplate(tpl)}
                    className="w-full py-2 px-4 text-xs font-medium rounded-lg border border-white/12 text-[#F2F4F8] hover:border-[#E59F3E] hover:text-[#E59F3E] transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    {busy ? "Creating Project..." : "Clone Template Project"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* New Project Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#12151B] border border-white/12 rounded-xl max-w-lg w-full p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-[#F2F4F8] font-display">
                Create Studio Project
              </h2>
              <button
                type="button"
                aria-label="Close modal"
                onClick={() => setModalOpen(false)}
                className="p-1.5 text-neutral-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={(e) => void handleCreateSubmit(e)} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-neutral-300">
                  Project Title
                </label>
                <input
                  type="text"
                  required
                  maxLength={120}
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g., Solaris Transit"
                  className="w-full px-3 py-2 text-sm bg-[#0B0D10] border border-white/12 rounded-lg text-[#F2F4F8] placeholder:text-neutral-500 focus:outline-none focus:border-[#E59F3E]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-neutral-300">Genre</label>
                  <input
                    type="text"
                    maxLength={60}
                    value={genre}
                    onChange={(e) => setGenre(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-[#0B0D10] border border-white/12 rounded-lg text-[#F2F4F8] focus:outline-none focus:border-[#E59F3E]"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-neutral-300">
                    Aspect Ratio
                  </label>
                  <select
                    value={aspectRatio}
                    onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
                    className="w-full px-3 py-2 text-xs bg-[#0B0D10] border border-white/12 rounded-lg text-[#F2F4F8] focus:outline-none focus:border-[#E59F3E]"
                  >
                    <option value="16:9">16:9 Cinema</option>
                    <option value="9:16">9:16 Vertical</option>
                    <option value="1:1">1:1 Square</option>
                    <option value="4:3">4:3 Academy</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-neutral-300">
                    Visual Style
                  </label>
                  <select
                    value={visualStyle}
                    onChange={(e) => setVisualStyle(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-[#0B0D10] border border-white/12 rounded-lg text-[#F2F4F8] focus:outline-none focus:border-[#E59F3E]"
                  >
                    {VISUAL_STYLES.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-neutral-300">
                  Story Logline / Synopsis
                </label>
                <textarea
                  rows={3}
                  maxLength={2000}
                  value={synopsis}
                  onChange={(e) => setSynopsis(e.target.value)}
                  placeholder="Outline the mood, characters, and story arc..."
                  className="w-full px-3 py-2 text-sm bg-[#0B0D10] border border-white/12 rounded-lg text-[#F2F4F8] placeholder:text-neutral-500 focus:outline-none focus:border-[#E59F3E]"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium rounded-lg border border-white/12 text-neutral-300 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting || !title.trim()}
                  className="px-5 py-2 text-xs font-semibold rounded-lg bg-[#E59F3E] text-[#0B0D10] hover:bg-[#F0AE52] disabled:opacity-50 transition-colors cursor-pointer"
                >
                  {submitting ? "Creating..." : "Create Project"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
}
