import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Clapperboard,
  Download,
  Film,
  Loader2,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Scissors,
  Trash2,
} from "lucide-react";
import type {
  MediaAsset,
  StoryboardScene,
  StudioProject,
  TimelineClip,
  TransitionType,
} from "../types/studio";
import {
  addTimelineClip,
  deleteTimelineClip,
  swapTimelineClipOrder,
  updateTimelineClip,
} from "../services/firestoreService";
import { SafeMediaImage } from "./MediaFallback";

interface SceneBuilderTimelineProps {
  uid: string;
  project: StudioProject;
  clips: TimelineClip[];
  scenes: StoryboardScene[];
  assets: MediaAsset[];
}

function formatTimecode(sec: number): string {
  const safe = Math.max(0, sec);
  const mins = Math.floor(safe / 60);
  const rem = safe - mins * 60;
  return `${String(mins).padStart(2, "0")}:${rem.toFixed(1).padStart(4, "0")}`;
}

export function SceneBuilderTimeline({
  uid,
  project,
  clips,
  scenes,
  assets,
}: SceneBuilderTimelineProps) {
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playheadTime, setPlayheadTime] = useState(0);
  const [exporting, setExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [feedback, setFeedback] = useState<{ type: "error" | "success"; text: string } | null>(
    null
  );

  const videoRef = useRef<HTMLVideoElement>(null);
  const lastFrameTsRef = useRef<number | null>(null);

  const clipRanges = useMemo(() => {
    let cursor = 0;
    return clips.map((clip) => {
      const dur = Math.max(0.5, clip.trimEnd - clip.trimStart);
      const start = cursor;
      const end = cursor + dur;
      cursor = end;
      return { clip, start, end, duration: dur };
    });
  }, [clips]);

  const totalDuration = clipRanges.length > 0 ? clipRanges[clipRanges.length - 1].end : 0;

  const activeRange = useMemo(() => {
    if (clipRanges.length === 0) return null;
    const found = clipRanges.find((r) => playheadTime >= r.start && playheadTime < r.end);
    return found || clipRanges[clipRanges.length - 1];
  }, [clipRanges, playheadTime]);

  const selectedClip = useMemo(
    () => clips.find((c) => c.id === selectedClipId) || clips[0] || null,
    [clips, selectedClipId]
  );

  // Sync playhead loop when playing
  useEffect(() => {
    if (!isPlaying || totalDuration <= 0) {
      lastFrameTsRef.current = null;
      return;
    }

    let rafId = 0;
    const tick = (now: number) => {
      if (lastFrameTsRef.current === null) {
        lastFrameTsRef.current = now;
      }
      const deltaSec = (now - lastFrameTsRef.current) / 1000;
      lastFrameTsRef.current = now;

      setPlayheadTime((prev) => {
        const next = prev + deltaSec;
        if (next >= totalDuration) {
          setIsPlaying(false);
          return 0;
        }
        return next;
      });
      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [isPlaying, totalDuration]);

  // Keep preview HTMLVideoElement synchronized with activeRange + playhead
  useEffect(() => {
    const vid = videoRef.current;
    if (!vid || !activeRange || activeRange.clip.mediaType !== "video") return;

    const targetOffset = activeRange.clip.trimStart + (playheadTime - activeRange.start);
    if (Math.abs(vid.currentTime - targetOffset) > 0.35) {
      vid.currentTime = targetOffset;
    }
    if (isPlaying && vid.paused) {
      void vid.play().catch(() => {
        // Autoplay fallback handled by frame clock
      });
    } else if (!isPlaying && !vid.paused) {
      vid.pause();
    }
  }, [activeRange, playheadTime, isPlaying]);

  // Compute transition opacity for preview monitor
  const transitionOpacity = useMemo(() => {
    if (!activeRange) return 1;
    const localTime = playheadTime - activeRange.start;
    if (activeRange.clip.transition === "crossfade" && localTime < 0.6) {
      return Math.max(0.15, localTime / 0.6);
    }
    if (activeRange.clip.transition === "dip-to-black") {
      if (localTime < 0.4) return localTime / 0.4;
      if (activeRange.duration - localTime < 0.4) {
        return Math.max(0, (activeRange.duration - localTime) / 0.4);
      }
    }
    return 1;
  }, [activeRange, playheadTime]);

  async function handleImportAllScenes() {
    const readyScenes = scenes.filter((s) => s.mediaUrl && s.mediaType !== "none");
    if (readyScenes.length === 0) {
      setFeedback({
        type: "error",
        text: "No storyboard scenes with generated images or videos yet.",
      });
      return;
    }
    let idx = clips.length;
    for (const sc of readyScenes) {
      await addTimelineClip({
        projectId: project.id,
        ownerId: uid,
        sceneId: sc.id,
        assetId: sc.assetId || "",
        title: sc.title,
        mediaUrl: sc.mediaUrl!,
        mediaType: sc.mediaType as "image" | "video",
        orderIndex: idx++,
        sourceDuration: sc.durationSeconds || 6,
      });
    }
    setFeedback({
      type: "success",
      text: `Imported ${readyScenes.length} scenes onto the timeline.`,
    });
  }

  async function handleAddAssetToTimeline(asset: MediaAsset) {
    if (!asset.url) return;
    await addTimelineClip({
      projectId: project.id,
      ownerId: uid,
      assetId: asset.id,
      title: asset.title,
      mediaUrl: asset.url,
      mediaType: asset.assetType,
      orderIndex: clips.length,
      sourceDuration: parseInt(asset.duration || "6", 10) || 6,
    });
  }

  async function handleExportCompleteMovie() {
    if (clips.length === 0) return;
    setExporting(true);
    setExportProgress(0);
    setIsPlaying(false);
    setFeedback(null);

    try {
      const canvas = document.createElement("canvas");
      canvas.width = project.aspectRatio === "9:16" ? 720 : 1280;
      canvas.height = project.aspectRatio === "9:16" ? 1280 : 720;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Canvas export is unsupported in this browser.");

      const stream = canvas.captureStream(30);
      const mimeType = MediaRecorder.isTypeSupported("video/webm;codecs=vp9")
        ? "video/webm;codecs=vp9"
        : "video/webm";
      const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 4_000_000 });
      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };

      const recordingDone = new Promise<Blob>((resolve) => {
        recorder.onstop = () => resolve(new Blob(chunks, { type: "video/webm" }));
      });

      recorder.start();

      let elapsedTotal = 0;
      for (const range of clipRanges) {
        const clip = range.clip;
        const clipDurationMs = range.duration * 1000;

        if (clip.mediaType === "image") {
          const img = new Image();
          img.crossOrigin = "anonymous";
          await new Promise<void>((res, rej) => {
            img.onload = () => res();
            img.onerror = () => rej(new Error(`Could not load image for "${clip.title}".`));
            img.src = clip.mediaUrl;
          });

          const startMs = performance.now();
          while (performance.now() - startMs < clipDurationMs) {
            const localSec = (performance.now() - startMs) / 1000;
            ctx.fillStyle = "#000000";
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Cover fit
            const scale = Math.max(canvas.width / img.width, canvas.height / img.height);
            const w = img.width * scale;
            const h = img.height * scale;
            ctx.globalAlpha =
              clip.transition === "dip-to-black" && localSec < 0.4 ? localSec / 0.4 : 1;
            ctx.drawImage(img, (canvas.width - w) / 2, (canvas.height - h) / 2, w, h);
            ctx.globalAlpha = 1;

            setExportProgress(
              Math.min(99, Math.round(((elapsedTotal + localSec) / totalDuration) * 100))
            );
            await new Promise((r) => setTimeout(r, 33));
          }
        } else {
          const vid = document.createElement("video");
          vid.crossOrigin = "anonymous";
          vid.muted = true;
          vid.playsInline = true;
          vid.src = clip.mediaUrl;
          await new Promise<void>((res, rej) => {
            vid.onloadeddata = () => res();
            vid.onerror = () => rej(new Error(`Could not load video for "${clip.title}".`));
          });
          vid.currentTime = clip.trimStart;
          await vid.play();

          const startMs = performance.now();
          while (performance.now() - startMs < clipDurationMs) {
            const localSec = (performance.now() - startMs) / 1000;
            ctx.fillStyle = "#000000";
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            const scale = Math.max(
              canvas.width / (vid.videoWidth || 1280),
              canvas.height / (vid.videoHeight || 720)
            );
            const w = (vid.videoWidth || 1280) * scale;
            const h = (vid.videoHeight || 720) * scale;
            ctx.drawImage(vid, (canvas.width - w) / 2, (canvas.height - h) / 2, w, h);
            setExportProgress(
              Math.min(99, Math.round(((elapsedTotal + localSec) / totalDuration) * 100))
            );
            await new Promise((r) => setTimeout(r, 33));
          }
          vid.pause();
        }
        elapsedTotal += range.duration;
      }

      recorder.stop();
      const finalBlob = await recordingDone;
      const dlUrl = URL.createObjectURL(finalBlob);
      const a = document.createElement("a");
      a.href = dlUrl;
      a.download = `${project.title.toLowerCase().replace(/[^a-z0-9]+/g, "_")}_final_cut.webm`;
      a.click();
      URL.revokeObjectURL(dlUrl);
      setExportProgress(100);
      setFeedback({ type: "success", text: "Final movie rendered and downloaded (.webm)." });
    } catch (err) {
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Could not export final video.",
      });
    } finally {
      setExporting(false);
    }
  }

  const completedAssets = assets.filter((a) => a.status === "Completed" && a.url);

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="pb-5 border-b border-white/8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs text-neutral-400">
            Projects / <span className="text-neutral-200">{project.title}</span> / Scene Builder
          </p>
          <h1 className="text-xl sm:text-2xl font-semibold text-[#F2F4F8] font-display mt-0.5">
            Timeline &amp; Story Assembly
          </h1>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => void handleImportAllScenes()}
            className="px-3.5 py-2 text-xs font-medium rounded-lg bg-[#12151B] border border-white/12 text-[#F2F4F8] hover:border-white/25 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Import Storyboard Scenes</span>
          </button>
          <button
            type="button"
            disabled={exporting || clips.length === 0}
            onClick={() => void handleExportCompleteMovie()}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#E59F3E] text-[#0B0D10] hover:bg-[#F0AE52] disabled:opacity-50 inline-flex items-center gap-1.5 cursor-pointer"
          >
            {exporting ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Download className="w-3.5 h-3.5" />
            )}
            <span>
              {exporting ? `Rendering ${exportProgress}%...` : "Export Complete Film"}
            </span>
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-4 ${
            feedback.type === "error"
              ? "bg-red-500/10 border-red-500/30 text-red-300"
              : "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
          }`}
        >
          <span>{feedback.text}</span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="underline hover:text-white cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Upper Editor Split: Program Monitor + Media Bin */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Program Preview Monitor */}
        <section className="lg:col-span-8 bg-[#12151B] border border-white/8 rounded-xl overflow-hidden">
          <div className="aspect-video bg-black relative flex items-center justify-center overflow-hidden">
            {activeRange ? (
              <div
                className="w-full h-full transition-opacity duration-150"
                style={{ opacity: transitionOpacity }}
              >
                {activeRange.clip.mediaType === "video" ? (
                  <video
                    ref={videoRef}
                    src={activeRange.clip.mediaUrl}
                    muted
                    playsInline
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <SafeMediaImage
                    src={activeRange.clip.mediaUrl}
                    alt={activeRange.clip.title}
                    className="w-full h-full object-contain"
                  />
                )}
              </div>
            ) : (
              <div className="text-center space-y-2 p-6 text-neutral-500">
                <Clapperboard className="w-8 h-8 mx-auto text-neutral-600" />
                <p className="text-xs">
                  Add scenes or media clips from the Project Bin to preview your assembled film.
                </p>
              </div>
            )}

            {activeRange && (
              <div className="absolute top-3 left-3 px-2.5 py-1 rounded bg-black/70 text-[11px] text-neutral-200 font-mono tabular-nums">
                {activeRange.clip.title}
              </div>
            )}
          </div>

          {/* Transport & Scrubber Bar */}
          <div className="p-4 border-t border-white/8 space-y-3">
            <input
              type="range"
              min={0}
              max={Math.max(0.5, totalDuration)}
              step={0.1}
              value={playheadTime}
              onChange={(e) => {
                setIsPlaying(false);
                setPlayheadTime(Number(e.target.value));
              }}
              className="w-full accent-[#E59F3E]"
            />
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={clips.length === 0}
                  onClick={() => setIsPlaying((p) => !p)}
                  className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-[#E59F3E] text-[#0B0D10] hover:bg-[#F0AE52] disabled:opacity-40 inline-flex items-center gap-1.5 cursor-pointer"
                >
                  {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isPlaying ? "Pause" : "Preview Story"}</span>
                </button>
                <button
                  type="button"
                  disabled={clips.length === 0}
                  onClick={() => {
                    setIsPlaying(false);
                    setPlayheadTime(0);
                  }}
                  className="p-1.5 rounded-lg border border-white/10 text-neutral-300 hover:text-white cursor-pointer"
                  aria-label="Restart preview"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="text-xs font-mono tabular-nums text-neutral-300">
                {formatTimecode(playheadTime)}{" "}
                <span className="text-neutral-500">/ {formatTimecode(totalDuration)}</span>
              </div>
            </div>
          </div>
        </section>

        {/* Clip Trim Inspector & Project Bin */}
        <section className="lg:col-span-4 space-y-4">
          {/* Selected Clip Trim Inspector */}
          <div className="bg-[#12151B] border border-white/8 rounded-xl p-4 space-y-3.5">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-[#F2F4F8] font-display inline-flex items-center gap-1.5">
                <Scissors className="w-4 h-4 text-[#E59F3E]" />
                <span>Clip Inspector</span>
              </h2>
              {selectedClip && (
                <span className="text-[11px] font-mono tabular-nums text-neutral-400">
                  {(selectedClip.trimEnd - selectedClip.trimStart).toFixed(1)}s active
                </span>
              )}
            </div>

            {!selectedClip ? (
              <p className="text-xs text-neutral-500">
                Select a clip on the timeline below to define its start, end, and transition.
              </p>
            ) : (
              <div className="space-y-3">
                <p className="text-xs font-medium text-neutral-200 truncate">
                  {selectedClip.title}
                </p>
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px] text-neutral-400 font-mono tabular-nums">
                    <span>Trim Start (In)</span>
                    <span>{selectedClip.trimStart.toFixed(1)}s</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={Math.max(0, selectedClip.trimEnd - 0.5)}
                    step={0.5}
                    value={selectedClip.trimStart}
                    onChange={(e) =>
                      void updateTimelineClip(project.id, selectedClip.id, {
                        trimStart: Number(e.target.value),
                      })
                    }
                    className="w-full accent-[#E59F3E]"
                  />
                </div>

                <div className="space-y-1.5">
                  <div className="flex justify-between text-[11px] text-neutral-400 font-mono tabular-nums">
                    <span>Trim End (Out)</span>
                    <span>{selectedClip.trimEnd.toFixed(1)}s</span>
                  </div>
                  <input
                    type="range"
                    min={Math.min(selectedClip.sourceDuration, selectedClip.trimStart + 0.5)}
                    max={selectedClip.sourceDuration}
                    step={0.5}
                    value={selectedClip.trimEnd}
                    onChange={(e) =>
                      void updateTimelineClip(project.id, selectedClip.id, {
                        trimEnd: Number(e.target.value),
                      })
                    }
                    className="w-full accent-[#E59F3E]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] text-neutral-400 block">
                    Incoming Transition
                  </label>
                  <select
                    value={selectedClip.transition}
                    onChange={(e) =>
                      void updateTimelineClip(project.id, selectedClip.id, {
                        transition: e.target.value as TransitionType,
                      })
                    }
                    className="w-full px-2.5 py-1.5 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-neutral-200 focus:outline-none focus:border-[#E59F3E]"
                  >
                    <option value="cut">Hard Cut</option>
                    <option value="crossfade">Crossfade</option>
                    <option value="dip-to-black">Dip to Black</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          {/* Project Media Bin */}
          <div className="bg-[#12151B] border border-white/8 rounded-xl p-4 space-y-3">
            <h2 className="text-sm font-semibold text-[#F2F4F8] font-display">
              Project Media Bin ({completedAssets.length})
            </h2>
            {completedAssets.length === 0 ? (
              <p className="text-xs text-neutral-500">
                Generate images or videos in Workspace to add them here.
              </p>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {completedAssets.map((asset) => (
                  <div
                    key={asset.id}
                    className="flex items-center justify-between gap-2 p-2 rounded-lg bg-[#0B0D10] border border-white/6"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-12 h-8 rounded overflow-hidden bg-[#12151B] shrink-0">
                        {asset.assetType === "video" ? (
                          <video
                            src={asset.url}
                            muted
                            preload="metadata"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <SafeMediaImage src={asset.url} alt={asset.title} />
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs text-neutral-200 truncate">{asset.title}</p>
                        <p className="text-[11px] text-neutral-500 font-mono tabular-nums">
                          {asset.assetType} {asset.duration ? `· ${asset.duration}` : ""}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => void handleAddAssetToTimeline(asset)}
                      className="px-2.5 py-1 text-[11px] font-medium rounded bg-[#181C24] text-[#E59F3E] hover:bg-[#232836] shrink-0 cursor-pointer"
                    >
                      + Add
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Horizontal Sequence Timeline Track */}
      <section className="bg-[#12151B] border border-white/8 rounded-xl p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-[#F2F4F8] font-display">
            Sequence Timeline ({clips.length} clips ·{" "}
            <span className="font-mono tabular-nums text-[#E59F3E]">
              {formatTimecode(totalDuration)}
            </span>
            )
          </h2>
          <span className="text-xs text-neutral-400">
            Click a clip to trim or reorder sequence
          </span>
        </div>

        {clips.length === 0 ? (
          <div className="py-8 border border-dashed border-white/10 rounded-lg text-center text-xs text-neutral-500 flex flex-col items-center gap-2">
            <Film className="w-5 h-5 text-neutral-600" />
            <span>Timeline track is empty. Import storyboard scenes or add clips from the bin.</span>
          </div>
        ) : (
          <div className="flex items-stretch gap-2 overflow-x-auto pb-2">
            {clipRanges.map((range, index) => {
              const { clip, start, duration } = range;
              const isSelected = selectedClip?.id === clip.id;
              const widthPx = Math.max(150, Math.round(duration * 28));

              return (
                <div
                  key={clip.id}
                  style={{ width: `${widthPx}px` }}
                  onClick={() => {
                    setSelectedClipId(clip.id);
                    setPlayheadTime(start);
                  }}
                  className={`shrink-0 rounded-lg border p-2.5 flex flex-col justify-between gap-2 cursor-pointer transition-colors ${
                    isSelected
                      ? "bg-[#1A1F29] border-[#E59F3E]"
                      : "bg-[#0B0D10] border-white/10 hover:border-white/25"
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-[11px] font-medium text-[#F2F4F8] truncate">
                      {index + 1}. {clip.title}
                    </span>
                    <span className="text-[10px] font-mono tabular-nums text-[#E59F3E] shrink-0">
                      {duration.toFixed(1)}s
                    </span>
                  </div>

                  <div className="h-12 rounded overflow-hidden bg-[#12151B]">
                    {clip.mediaType === "video" ? (
                      <video
                        src={clip.mediaUrl}
                        muted
                        preload="metadata"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <SafeMediaImage src={clip.mediaUrl} alt={clip.title} />
                    )}
                  </div>

                  <div
                    className="flex items-center justify-between gap-1 pt-1 border-t border-white/6"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        disabled={index === 0}
                        aria-label="Move clip left"
                        onClick={() =>
                          void swapTimelineClipOrder(project.id, clip, clips[index - 1])
                        }
                        className="p-1 text-neutral-400 hover:text-white disabled:opacity-30 cursor-pointer"
                      >
                        <ArrowLeft className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        disabled={index === clips.length - 1}
                        aria-label="Move clip right"
                        onClick={() =>
                          void swapTimelineClipOrder(project.id, clip, clips[index + 1])
                        }
                        className="p-1 text-neutral-400 hover:text-white disabled:opacity-30 cursor-pointer"
                      >
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                    <span className="text-[10px] text-neutral-500 capitalize">
                      {clip.transition}
                    </span>
                    <button
                      type="button"
                      aria-label={`Remove ${clip.title}`}
                      onClick={() => void deleteTimelineClip(project.id, clip.id)}
                      className="p-1 text-neutral-500 hover:text-red-400 cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
