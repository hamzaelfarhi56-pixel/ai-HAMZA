import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  Clapperboard,
  Film,
  Image as ImageIcon,
  Layers,
  Loader2,
  Play,
  Sparkles,
  Trash2,
  Upload,
  Users,
  Video,
  Wand2,
} from "lucide-react";
import {
  calculateGenerationCreditCost,
  CAMERA_MOVEMENTS,
  IMAGE_RESOLUTIONS,
  VIDEO_RESOLUTIONS,
  VISUAL_STYLES,
  type AspectRatio,
  type CharacterEntity,
  type MediaAsset,
  type StudioProject,
} from "../types/studio";
import {
  callStudioAssistant,
  pollGenerationJob,
  startImageGeneration,
  startVideoGeneration,
  uploadReferenceFile,
} from "../services/apiClient";
import {
  addTimelineClip,
  createAsset,
  createScene,
  deductUserCredits,
  deleteAsset,
  refundUserCredits,
  updateAssetStatus,
  updateProjectCounts,
} from "../services/firestoreService";
import { PipelineStatusLabel, SafeMediaImage } from "./MediaFallback";

type CreationMode =
  | "text-to-video"
  | "image-to-video"
  | "keyframe-motion"
  | "text-to-image"
  | "video-edit";

interface WorkspaceGeneratorProps {
  uid: string;
  project: StudioProject;
  credits: number;
  characters: CharacterEntity[];
  assets: MediaAsset[];
  sceneCount: number;
  timelineCount: number;
  draftPromptFromAssistant?: string;
  preselectedCharIds?: string[];
  onClearDraftPrompt?: () => void;
  onGoToCharacters: () => void;
  onGoToStoryboard: () => void;
  onGoToTimeline: () => void;
}

export function WorkspaceGenerator({
  uid,
  project,
  credits,
  characters,
  assets,
  sceneCount,
  timelineCount,
  draftPromptFromAssistant,
  preselectedCharIds,
  onClearDraftPrompt,
  onGoToCharacters,
  onGoToStoryboard,
  onGoToTimeline,
}: WorkspaceGeneratorProps) {
  const [mode, setMode] = useState<CreationMode>("text-to-video");
  const [prompt, setPrompt] = useState("");
  const [title, setTitle] = useState("");
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>(project.aspectRatio || "16:9");
  const [durationSeconds, setDurationSeconds] = useState<number>(8);
  const [videoResolution, setVideoResolution] = useState<string>("720p");
  const [imageResolution, setImageResolution] = useState<string>("1K");
  const [cameraMovement, setCameraMovement] = useState<string>(CAMERA_MOVEMENTS[1]);
  const [visualStyle, setVisualStyle] = useState<string>(
    project.visualStyle || VISUAL_STYLES[0]
  );

  const [selectedCharIds, setSelectedCharIds] = useState<string[]>(preselectedCharIds || []);
  const [selectedRefUrls, setSelectedRefUrls] = useState<string[]>([]);
  const [startImageUrl, setStartImageUrl] = useState<string>("");
  const [endImageUrl, setEndImageUrl] = useState<string>("");
  const [refVideoUrl, setRefVideoUrl] = useState<string>("");

  const [assetFilter, setAssetFilter] = useState<"all" | "video" | "image" | "upload">("all");
  const [uploading, setUploading] = useState(false);
  const [enhancing, setEnhancing] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [liveStageMap, setLiveStageMap] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState<{ type: "error" | "success"; text: string } | null>(
    null
  );
  const [previewAsset, setPreviewAsset] = useState<MediaAsset | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (draftPromptFromAssistant) {
      setPrompt(draftPromptFromAssistant);
      onClearDraftPrompt?.();
    }
  }, [draftPromptFromAssistant, onClearDraftPrompt]);

  useEffect(() => {
    if (preselectedCharIds && preselectedCharIds.length > 0) {
      setSelectedCharIds(preselectedCharIds);
    }
  }, [preselectedCharIds]);

  const isImageMode = mode === "text-to-image";
  const maxDuration = mode === "keyframe-motion" ? 10 : 15;
  const effectiveDuration = Math.min(durationSeconds, maxDuration);
  const creditCost = calculateGenerationCreditCost({
    kind: isImageMode ? "image" : "video",
    resolution: isImageMode ? imageResolution : videoResolution,
    durationSeconds: effectiveDuration,
  });

  const imageAssets = assets.filter((a) => a.assetType === "image" && a.url);
  const videoAssets = assets.filter((a) => a.assetType === "video" && a.url);

  const filteredAssets = assets.filter((a) => {
    if (assetFilter === "video") return a.assetType === "video";
    if (assetFilter === "image") return a.assetType === "image";
    if (assetFilter === "upload") return a.source === "upload";
    return true;
  });

  function toggleChar(id: string) {
    setSelectedCharIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : prev.length < 6 ? [...prev, id] : prev
    );
  }

  function toggleRefUrl(url: string) {
    setSelectedRefUrls((prev) =>
      prev.includes(url) ? prev.filter((x) => x !== url) : prev.length < 3 ? [...prev, url] : prev
    );
  }

  async function handleFileUpload(files: FileList | null) {
    if (!files || files.length === 0) return;
    setUploading(true);
    setFeedback(null);
    try {
      for (const file of Array.from(files).slice(0, 4)) {
        const uploaded = await uploadReferenceFile(file);
        const isVideo = uploaded.mimeType.startsWith("video/");
        await createAsset({
          projectId: project.id,
          ownerId: uid,
          title: uploaded.name.replace(/\.[^.]+$/, ""),
          assetType: isVideo ? "video" : "image",
          source: "upload",
          url: uploaded.url,
          mimeType: uploaded.mimeType,
          generationMode: "upload",
          aspectRatio,
          status: "Completed",
          creditCost: 0,
        });

        if (isVideo) {
          setRefVideoUrl(uploaded.url);
        } else if (mode === "image-to-video" || mode === "keyframe-motion") {
          if (!startImageUrl) setStartImageUrl(uploaded.url);
          else if (mode === "keyframe-motion" && !endImageUrl) setEndImageUrl(uploaded.url);
          else setSelectedRefUrls((prev) => [...prev.slice(0, 2), uploaded.url]);
        } else {
          setSelectedRefUrls((prev) => [...prev.slice(0, 2), uploaded.url]);
        }
      }

      await updateProjectCounts(project.id, {
        assetCount: assets.length + files.length,
      });
      setFeedback({ type: "success", text: "Reference media uploaded to project vault." });
    } catch (err) {
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Upload failed.",
      });
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function handleEnhancePrompt() {
    if (!prompt.trim()) {
      setFeedback({ type: "error", text: "Enter a rough idea before enhancing the prompt." });
      return;
    }
    setEnhancing(true);
    setFeedback(null);
    try {
      const selectedChars = characters
        .filter((c) => selectedCharIds.includes(c.id))
        .map((c) => ({
          name: c.name,
          entityType: c.entityType,
          appearancePrompt: c.appearancePrompt,
        }));

      const res = await callStudioAssistant({
        mode: "enhance-prompt",
        message: prompt,
        projectContext: {
          title: project.title,
          synopsis: project.synopsis,
          visualStyle,
          characters: selectedChars,
        },
      });
      const data = res.data as {
        enhancedPrompt?: string;
        suggestedCamera?: string;
        suggestedStyle?: string;
      };
      if (data?.enhancedPrompt) {
        setPrompt(data.enhancedPrompt);
      }
      if (data?.suggestedCamera && CAMERA_MOVEMENTS.includes(data.suggestedCamera as never)) {
        setCameraMovement(data.suggestedCamera);
      }
      setFeedback({ type: "success", text: "Prompt refined with cinematography details." });
    } catch (err) {
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Prompt enhancement failed.",
      });
    } finally {
      setEnhancing(false);
    }
  }

  async function handleGenerate() {
    if (!prompt.trim()) {
      setFeedback({ type: "error", text: "Write a prompt describing the shot or image." });
      return;
    }
    if (mode === "image-to-video" && !startImageUrl) {
      setFeedback({
        type: "error",
        text: "Select or upload a starting image frame for Image-to-Video.",
      });
      return;
    }
    if (mode === "keyframe-motion" && (!startImageUrl || !endImageUrl)) {
      setFeedback({
        type: "error",
        text: "Select both a Start Frame and an End Frame to guide keyframe motion.",
      });
      return;
    }
    if (mode === "video-edit" && !refVideoUrl) {
      setFeedback({
        type: "error",
        text: "Select or upload a source video clip for Video-to-Video editing.",
      });
      return;
    }
    if (credits < creditCost) {
      setFeedback({
        type: "error",
        text: `Not enough credits (${credits} remaining, ${creditCost} needed). Add studio credits from your Account menu.`,
      });
      return;
    }

    setSubmitting(true);
    setFeedback(null);

    const activeChars = characters
      .filter((c) => selectedCharIds.includes(c.id))
      .map((c) => ({
        name: c.name,
        entityType: c.entityType,
        appearancePrompt: c.appearancePrompt,
        referenceImageUrl: c.referenceImageUrl,
      }));

    let createdAssetId = "";
    let creditsDeducted = false;

    try {
      await deductUserCredits(uid, creditCost);
      creditsDeducted = true;

      const assetTitle =
        title.trim() ||
        prompt
          .trim()
          .split(/\s+/)
          .slice(0, 6)
          .join(" ");

      const resolvedMode =
        mode === "text-to-image"
          ? selectedRefUrls.length > 0
            ? "image-edit"
            : "text-to-image"
          : mode;

      createdAssetId = await createAsset({
        projectId: project.id,
        ownerId: uid,
        title: assetTitle,
        assetType: isImageMode ? "image" : "video",
        source: "generated",
        prompt: prompt.trim(),
        generationMode: resolvedMode,
        aspectRatio,
        duration: isImageMode ? "" : `${effectiveDuration}s`,
        resolution: isImageMode ? imageResolution : videoResolution,
        cameraMovement,
        visualStyle,
        characterIds: selectedCharIds,
        status: "Generating",
        creditCost,
      });

      await updateProjectCounts(project.id, {
        assetCount: assets.length + 1,
      });

      const jobInit = isImageMode
        ? await startImageGeneration({
            prompt: prompt.trim(),
            aspectRatio,
            resolution: imageResolution,
            visualStyle,
            cameraMovement,
            referenceUrls: selectedRefUrls,
            characters: activeChars,
          })
        : await startVideoGeneration({
            mode,
            prompt: prompt.trim(),
            aspectRatio,
            durationSeconds: effectiveDuration,
            resolution: videoResolution,
            visualStyle,
            cameraMovement,
            startImageUrl: startImageUrl || undefined,
            endImageUrl: endImageUrl || undefined,
            referenceVideoUrl: refVideoUrl || undefined,
            referenceUrls: selectedRefUrls,
            characters: activeChars,
          });

      setLiveStageMap((m) => ({ ...m, [createdAssetId]: jobInit.stageLabel }));
      setTitle("");
      setSubmitting(false);

      // Background pipeline monitor so user can queue multiple concurrent requests!
      let lastStatus = "Generating";
      const finalJob = await pollGenerationJob(jobInit.jobId, (progress) => {
        setLiveStageMap((m) => ({ ...m, [createdAssetId]: progress.stageLabel }));
        if (progress.status !== lastStatus && progress.status === "Processing") {
          lastStatus = "Processing";
          void updateAssetStatus(project.id, createdAssetId, { status: "Processing" });
        }
      });

      if (finalJob.status === "Completed" && finalJob.result?.url) {
        await updateAssetStatus(project.id, createdAssetId, {
          status: "Completed",
          url: finalJob.result.url,
          mimeType: finalJob.result.mimeType,
          interactionId: finalJob.result.interactionId || "",
        });
        if (!project.thumbnailUrl && isImageMode) {
          await updateProjectCounts(project.id, { thumbnailUrl: finalJob.result.url });
        }
      } else {
        const errText = finalJob.errorMessage || "Generation failed.";
        await updateAssetStatus(project.id, createdAssetId, {
          status: "Failed",
          errorMessage: errText,
        });
        await refundUserCredits(uid, creditCost);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to launch generation.";
      setFeedback({ type: "error", text: msg });
      if (createdAssetId) {
        await updateAssetStatus(project.id, createdAssetId, {
          status: "Failed",
          errorMessage: msg,
        });
      }
      if (creditsDeducted) {
        await refundUserCredits(uid, creditCost);
      }
      setSubmitting(false);
    }
  }

  async function handleSendToStoryboard(asset: MediaAsset) {
    if (!asset.url) return;
    try {
      await createScene({
        projectId: project.id,
        ownerId: uid,
        orderIndex: sceneCount,
        title: asset.title,
        prompt: asset.prompt || asset.title,
        notes: `Created in Workspace (${asset.generationMode})`,
        mediaUrl: asset.url,
        mediaType: asset.assetType,
        assetId: asset.id,
        durationSeconds: parseInt(asset.duration || "8", 10) || 8,
        cameraMovement: asset.cameraMovement || "Static Locked",
        visualStyle: asset.visualStyle || project.visualStyle,
        characterIds: asset.characterIds || [],
        status: "Completed",
      });
      await updateProjectCounts(project.id, { sceneCount: sceneCount + 1 });
      setFeedback({ type: "success", text: `"${asset.title}" added to Storyboard.` });
    } catch (err) {
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Could not add to storyboard.",
      });
    }
  }

  async function handleSendToTimeline(asset: MediaAsset) {
    if (!asset.url) return;
    try {
      await addTimelineClip({
        projectId: project.id,
        ownerId: uid,
        assetId: asset.id,
        title: asset.title,
        mediaUrl: asset.url,
        mediaType: asset.assetType,
        orderIndex: timelineCount,
        sourceDuration: parseInt(asset.duration || "6", 10) || 6,
      });
      setFeedback({ type: "success", text: `"${asset.title}" added to Scene Builder Timeline.` });
    } catch (err) {
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Could not add to timeline.",
      });
    }
  }

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Project Context Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-white/8">
        <div>
          <p className="text-xs text-neutral-400">
            Projects / <span className="text-neutral-200">{project.title}</span> ·{" "}
            <span className="font-mono tabular-nums">{project.aspectRatio}</span> ·{" "}
            {project.visualStyle}
          </p>
          <h1 className="text-xl sm:text-2xl font-semibold text-[#F2F4F8] font-display mt-0.5">
            Creation Workspace
          </h1>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={onGoToCharacters}
            className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#12151B] border border-white/10 text-neutral-300 hover:text-white hover:border-white/25 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            <Users className="w-3.5 h-3.5 text-[#E59F3E]" />
            <span>Characters ({characters.length})</span>
          </button>
          <button
            type="button"
            onClick={onGoToStoryboard}
            className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#12151B] border border-white/10 text-neutral-300 hover:text-white hover:border-white/25 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            <Layers className="w-3.5 h-3.5 text-[#E59F3E]" />
            <span>Storyboard ({sceneCount})</span>
          </button>
          <button
            type="button"
            onClick={onGoToTimeline}
            className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#12151B] border border-white/10 text-neutral-300 hover:text-white hover:border-white/25 transition-colors inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            <Clapperboard className="w-3.5 h-3.5 text-[#E59F3E]" />
            <span>Scene Builder ({timelineCount})</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-4 ${
            feedback.type === "error"
              ? "bg-red-500/10 border-red-500/30 text-red-300"
              : "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
          }`}
        >
          <span>{feedback.text}</span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="underline hover:text-white cursor-pointer shrink-0"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Split: Left Generator Console + Right Media Vault & Pipeline */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Prompt & Cinema Parameters */}
        <section className="lg:col-span-7 bg-[#12151B] border border-white/8 rounded-xl p-5 sm:p-6 space-y-5">
          {/* Generation Mode Tabs */}
          <div className="flex flex-wrap items-center gap-1 p-1 bg-[#0B0D10] rounded-lg border border-white/6">
            {[
              { id: "text-to-video", label: "Text to Video" },
              { id: "image-to-video", label: "Image to Video" },
              { id: "keyframe-motion", label: "Start + End Frames" },
              { id: "text-to-image", label: "Image / Edit" },
              { id: "video-edit", label: "Video to Video" },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setMode(tab.id as CreationMode)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  mode === tab.id
                    ? "bg-[#E59F3E] text-[#0B0D10] font-semibold"
                    : "text-neutral-400 hover:text-white"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Shot Title + Prompt Box */}
          <div className="space-y-3">
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={140}
              placeholder="Shot title (optional, e.g., Alleyway Tracking Shot)"
              className="w-full px-3.5 py-2 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-[#F2F4F8] placeholder:text-neutral-500 focus:outline-none focus:border-[#E59F3E]"
            />

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-neutral-300">
                  Director Prompt
                </label>
                <button
                  type="button"
                  disabled={enhancing}
                  onClick={() => void handleEnhancePrompt()}
                  className="text-xs font-medium text-[#E59F3E] hover:text-[#F0AE52] inline-flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                >
                  {enhancing ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Wand2 className="w-3.5 h-3.5" />
                  )}
                  <span>{enhancing ? "Refining..." : "Enhance with AI"}</span>
                </button>
              </div>
              <textarea
                rows={4}
                maxLength={2500}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder={
                  mode === "image-to-video"
                    ? "Describe how the starting image should animate (motion, wind, camera push, lighting shift)..."
                    : mode === "keyframe-motion"
                      ? "Describe the transformation and camera path connecting the start frame to the end frame..."
                      : mode === "video-edit"
                        ? "Describe how to restyle, transform, or continue the selected video..."
                        : "Describe the subject, environment, lighting, lens, and action..."
                }
                className="w-full px-3.5 py-3 text-sm bg-[#0B0D10] border border-white/10 rounded-lg text-[#F2F4F8] placeholder:text-neutral-500 focus:outline-none focus:border-[#E59F3E] leading-relaxed"
              />
            </div>
          </div>

          {/* Character & Object Consistency Selector */}
          <div className="space-y-2 pt-2 border-t border-white/6">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-neutral-300">
                Character &amp; Object Consistency
              </span>
              <button
                type="button"
                onClick={onGoToCharacters}
                className="text-xs text-neutral-400 hover:text-[#E59F3E] cursor-pointer"
              >
                Manage Bible
              </button>
            </div>
            {characters.length === 0 ? (
              <p className="text-xs text-neutral-500">
                No characters or objects saved yet.{" "}
                <button
                  type="button"
                  onClick={onGoToCharacters}
                  className="text-[#E59F3E] hover:underline cursor-pointer"
                >
                  Create one to maintain consistency across scenes
                </button>
                .
              </p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {characters.map((ch) => {
                  const active = selectedCharIds.includes(ch.id);
                  return (
                    <button
                      key={ch.id}
                      type="button"
                      onClick={() => toggleChar(ch.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs border transition-colors inline-flex items-center gap-2 cursor-pointer ${
                        active
                          ? "bg-[#E59F3E]/15 border-[#E59F3E] text-[#F2F4F8]"
                          : "bg-[#0B0D10] border-white/10 text-neutral-400 hover:text-neutral-200"
                      }`}
                    >
                      {ch.referenceImageUrl && (
                        <img
                          src={ch.referenceImageUrl}
                          alt={ch.name}
                          referrerPolicy="no-referrer"
                          className="w-4 h-4 rounded object-cover"
                        />
                      )}
                      <span>{ch.name}</span>
                      <span className="text-[11px] text-neutral-500">{ch.entityType}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Keyframes & Visual Reference Uploader */}
          <div className="space-y-3 pt-2 border-t border-white/6">
            <div className="flex items-center justify-between gap-3">
              <span className="text-xs font-medium text-neutral-300">
                Visual References &amp; Keyframes
              </span>
              <div className="flex items-center gap-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,video/mp4,video/webm"
                  multiple
                  className="hidden"
                  onChange={(e) => void handleFileUpload(e.target.files)}
                />
                <button
                  type="button"
                  disabled={uploading}
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#0B0D10] border border-white/12 text-neutral-200 hover:border-[#E59F3E] inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {uploading ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Upload className="w-3.5 h-3.5" />
                  )}
                  <span>{uploading ? "Uploading..." : "Upload Image / Video"}</span>
                </button>
              </div>
            </div>

            {/* Mode-Specific Keyframe Slots */}
            {(mode === "image-to-video" || mode === "keyframe-motion") && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-lg bg-[#0B0D10] border border-white/8 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-neutral-300 font-medium">Start Frame</span>
                    {startImageUrl && (
                      <button
                        type="button"
                        onClick={() => setStartImageUrl("")}
                        className="text-neutral-500 hover:text-red-400 cursor-pointer"
                      >
                        Clear
                      </button>
                    )}
                  </div>
                  <select
                    value={startImageUrl}
                    onChange={(e) => setStartImageUrl(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs bg-[#12151B] border border-white/10 rounded-md text-neutral-200 focus:outline-none focus:border-[#E59F3E]"
                  >
                    <option value="">Select image from project...</option>
                    {imageAssets.map((img) => (
                      <option key={img.id} value={img.url}>
                        {img.title}
                      </option>
                    ))}
                  </select>
                </div>

                {mode === "keyframe-motion" && (
                  <div className="p-3 rounded-lg bg-[#0B0D10] border border-white/8 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-neutral-300 font-medium">End Frame</span>
                      {endImageUrl && (
                        <button
                          type="button"
                          onClick={() => setEndImageUrl("")}
                          className="text-neutral-500 hover:text-red-400 cursor-pointer"
                        >
                          Clear
                        </button>
                      )}
                    </div>
                    <select
                      value={endImageUrl}
                      onChange={(e) => setEndImageUrl(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs bg-[#12151B] border border-white/10 rounded-md text-neutral-200 focus:outline-none focus:border-[#E59F3E]"
                    >
                      <option value="">Select ending image...</option>
                      {imageAssets.map((img) => (
                        <option key={img.id} value={img.url}>
                          {img.title}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            )}

            {mode === "video-edit" && (
              <div className="p-3 rounded-lg bg-[#0B0D10] border border-white/8 space-y-2">
                <span className="text-xs font-medium text-neutral-300 block">
                  Source Video Clip
                </span>
                <select
                  value={refVideoUrl}
                  onChange={(e) => setRefVideoUrl(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-[#12151B] border border-white/10 rounded-md text-neutral-200 focus:outline-none focus:border-[#E59F3E]"
                >
                  <option value="">Select video from project...</option>
                  {videoAssets.map((vid) => (
                    <option key={vid.id} value={vid.url}>
                      {vid.title}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Multi-Image Style/Subject References */}
            {imageAssets.length > 0 && (
              <div className="space-y-1.5">
                <p className="text-xs text-neutral-400">
                  Additional Visual References ({selectedRefUrls.length}/3 selected)
                </p>
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {imageAssets.slice(0, 10).map((img) => {
                    const url = img.url || "";
                    const active = selectedRefUrls.includes(url);
                    return (
                      <button
                        key={img.id}
                        type="button"
                        onClick={() => toggleRefUrl(url)}
                        className={`relative w-16 h-11 rounded-md overflow-hidden border shrink-0 transition-all cursor-pointer ${
                          active
                            ? "border-[#E59F3E] ring-1 ring-[#E59F3E]"
                            : "border-white/10 opacity-70 hover:opacity-100"
                        }`}
                        title={img.title}
                      >
                        <SafeMediaImage src={url} alt={img.title} />
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Cinema Controls Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 border-t border-white/6">
            <div className="space-y-1">
              <label className="text-xs text-neutral-400 block">Aspect Ratio</label>
              <select
                value={aspectRatio}
                onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
                className="w-full px-2.5 py-2 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-neutral-200 focus:outline-none focus:border-[#E59F3E]"
              >
                <option value="16:9">16:9 Widescreen</option>
                <option value="9:16">9:16 Vertical</option>
                {isImageMode && <option value="1:1">1:1 Square</option>}
                {isImageMode && <option value="4:3">4:3 Classic</option>}
              </select>
            </div>

            {!isImageMode && (
              <div className="space-y-1">
                <label className="text-xs text-neutral-400 flex items-center justify-between">
                  <span>Duration</span>
                  <span className="font-mono tabular-nums text-neutral-200">
                    {effectiveDuration}s
                  </span>
                </label>
                <input
                  type="range"
                  min={3}
                  max={maxDuration}
                  step={1}
                  value={effectiveDuration}
                  onChange={(e) => setDurationSeconds(Number(e.target.value))}
                  className="w-full accent-[#E59F3E] mt-2"
                />
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs text-neutral-400 block">Resolution</label>
              {isImageMode ? (
                <select
                  value={imageResolution}
                  onChange={(e) => setImageResolution(e.target.value)}
                  className="w-full px-2.5 py-2 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-neutral-200 focus:outline-none focus:border-[#E59F3E]"
                >
                  {IMAGE_RESOLUTIONS.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              ) : (
                <select
                  value={videoResolution}
                  onChange={(e) => setVideoResolution(e.target.value)}
                  className="w-full px-2.5 py-2 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-neutral-200 focus:outline-none focus:border-[#E59F3E]"
                >
                  {VIDEO_RESOLUTIONS.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div className="space-y-1">
              <label className="text-xs text-neutral-400 block">Camera Movement</label>
              <select
                value={cameraMovement}
                onChange={(e) => setCameraMovement(e.target.value)}
                className="w-full px-2.5 py-2 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-neutral-200 focus:outline-none focus:border-[#E59F3E]"
              >
                {CAMERA_MOVEMENTS.map((cm) => (
                  <option key={cm} value={cm}>
                    {cm}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1 col-span-2 sm:col-span-2">
              <label className="text-xs text-neutral-400 block">Visual Style</label>
              <select
                value={visualStyle}
                onChange={(e) => setVisualStyle(e.target.value)}
                className="w-full px-2.5 py-2 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-neutral-200 focus:outline-none focus:border-[#E59F3E]"
              >
                {VISUAL_STYLES.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Primary Generate Action */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-white/8">
            <div className="text-xs text-neutral-400 font-mono tabular-nums">
              Cost: <span className="text-[#F2F4F8] font-semibold">{creditCost} cr</span> ·
              Balance: <span className="text-[#E59F3E]">{credits} cr</span>
            </div>
            <button
              type="button"
              disabled={submitting}
              onClick={() => void handleGenerate()}
              className="px-6 py-2.5 text-sm font-semibold rounded-lg bg-[#E59F3E] text-[#0B0D10] hover:bg-[#F0AE52] disabled:opacity-50 transition-colors inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              {submitting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4" />
              )}
              <span>{isImageMode ? "Generate Frame" : "Generate Video"}</span>
            </button>
          </div>
        </section>

        {/* Right: Active Pipeline & Project Media Vault */}
        <section className="lg:col-span-5 space-y-4">
          <div className="bg-[#12151B] border border-white/8 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-base font-semibold text-[#F2F4F8] font-display">
                Project Assets &amp; Pipeline
              </h2>
              <div className="flex items-center gap-1 p-0.5 bg-[#0B0D10] rounded-lg border border-white/8">
                {(["all", "video", "image", "upload"] as const).map((f) => (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setAssetFilter(f)}
                    className={`px-2.5 py-1 text-xs rounded-md capitalize cursor-pointer ${
                      assetFilter === f
                        ? "bg-[#181C24] text-white font-medium"
                        : "text-neutral-400 hover:text-neutral-200"
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            {filteredAssets.length === 0 ? (
              <div className="py-10 text-center space-y-2 border border-dashed border-white/10 rounded-lg">
                <Film className="w-6 h-6 text-neutral-600 mx-auto" />
                <p className="text-xs text-neutral-400">
                  Generated videos, frames, and uploaded references appear here.
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[680px] overflow-y-auto pr-1">
                {filteredAssets.map((asset) => {
                  const stage = liveStageMap[asset.id];
                  return (
                    <div
                      key={asset.id}
                      className="p-3 rounded-xl bg-[#0B0D10] border border-white/8 space-y-3"
                    >
                      <div className="flex items-start gap-3">
                        <div className="w-28 aspect-video rounded-lg overflow-hidden bg-[#12151B] shrink-0 relative">
                          {asset.status === "Completed" && asset.url ? (
                            asset.assetType === "video" ? (
                              <button
                                type="button"
                                onClick={() => setPreviewAsset(asset)}
                                className="w-full h-full relative group cursor-pointer"
                              >
                                <video
                                  src={asset.url}
                                  muted
                                  playsInline
                                  preload="metadata"
                                  className="w-full h-full object-cover"
                                />
                                <span className="absolute inset-0 bg-black/35 flex items-center justify-center group-hover:bg-black/20">
                                  <Play className="w-5 h-5 text-white fill-white" />
                                </span>
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setPreviewAsset(asset)}
                                className="w-full h-full cursor-pointer"
                              >
                                <SafeMediaImage src={asset.url} alt={asset.title} />
                              </button>
                            )
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-neutral-600">
                              {asset.assetType === "video" ? (
                                <Video className="w-5 h-5" />
                              ) : (
                                <ImageIcon className="w-5 h-5" />
                              )}
                            </div>
                          )}
                        </div>

                        <div className="min-w-0 flex-1 space-y-1">
                          <div className="flex items-center justify-between gap-2">
                            <h3 className="text-xs font-semibold text-[#F2F4F8] truncate">
                              {asset.title}
                            </h3>
                            <PipelineStatusLabel status={asset.status} stageLabel={stage} />
                          </div>
                          <p className="text-[11px] text-neutral-400 font-mono tabular-nums">
                            {asset.generationMode} · {asset.aspectRatio || "16:9"}
                            {asset.duration ? ` · ${asset.duration}` : ""}
                            {asset.resolution ? ` · ${asset.resolution}` : ""}
                            {asset.creditCost > 0 ? ` · ${asset.creditCost} cr` : ""}
                          </p>
                          {asset.errorMessage && (
                            <p className="text-[11px] text-red-400 leading-snug">
                              {asset.errorMessage}
                            </p>
                          )}
                        </div>
                      </div>

                      {asset.status === "Completed" && asset.url && (
                        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/6">
                          <div className="flex flex-wrap items-center gap-2 text-[11px]">
                            {asset.assetType === "image" && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setMode("image-to-video");
                                    setStartImageUrl(asset.url || "");
                                  }}
                                  className="text-neutral-300 hover:text-[#E59F3E] cursor-pointer"
                                >
                                  Animate
                                </button>
                                <span className="text-neutral-600">·</span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setMode("keyframe-motion");
                                    setEndImageUrl(asset.url || "");
                                  }}
                                  className="text-neutral-300 hover:text-[#E59F3E] cursor-pointer"
                                >
                                  Set End Frame
                                </button>
                                <span className="text-neutral-600">·</span>
                              </>
                            )}
                            <button
                              type="button"
                              onClick={() => void handleSendToStoryboard(asset)}
                              className="text-neutral-300 hover:text-[#E59F3E] inline-flex items-center gap-1 cursor-pointer"
                            >
                              <span>To Storyboard</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                            <span className="text-neutral-600">·</span>
                            <button
                              type="button"
                              onClick={() => void handleSendToTimeline(asset)}
                              className="text-[#E59F3E] hover:text-[#F0AE52] cursor-pointer"
                            >
                              + Timeline
                            </button>
                          </div>

                          <button
                            type="button"
                            aria-label={`Delete ${asset.title}`}
                            onClick={() => void deleteAsset(project.id, asset.id)}
                            className="p-1 text-neutral-500 hover:text-red-400 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Fullscreen Media Lightbox */}
      {previewAsset && previewAsset.url && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setPreviewAsset(null)}
        >
          <div
            className="max-w-4xl w-full bg-[#12151B] border border-white/12 rounded-xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-5 py-3.5 border-b border-white/8 flex items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-semibold text-[#F2F4F8] font-display">
                  {previewAsset.title}
                </h3>
                <p className="text-xs text-neutral-400 font-mono tabular-nums">
                  {previewAsset.assetType} · {previewAsset.aspectRatio}
                  {previewAsset.duration ? ` · ${previewAsset.duration}` : ""}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewAsset(null)}
                className="px-3 py-1 text-xs rounded-lg border border-white/12 text-neutral-300 hover:text-white cursor-pointer"
              >
                Close
              </button>
            </div>
            <div className="bg-black flex items-center justify-center max-h-[75vh]">
              {previewAsset.assetType === "video" ? (
                <video
                  src={previewAsset.url}
                  controls
                  autoPlay
                  className="max-h-[75vh] w-full object-contain"
                />
              ) : (
                <img
                  src={previewAsset.url}
                  alt={previewAsset.title}
                  referrerPolicy="no-referrer"
                  className="max-h-[75vh] w-full object-contain"
                />
              )}
            </div>
            {previewAsset.prompt && (
              <div className="px-5 py-3 border-t border-white/8 text-xs text-neutral-300">
                {previewAsset.prompt}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
