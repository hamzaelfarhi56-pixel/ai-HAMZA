import { useState } from "react";
import { Loader2, Send, Sparkles, X } from "lucide-react";
import type { CharacterEntity, StoryboardScene, StudioProject } from "../types/studio";
import { callStudioAssistant } from "../services/apiClient";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

interface AiAssistantDrawerProps {
  open: boolean;
  project: StudioProject;
  characters: CharacterEntity[];
  scenes: StoryboardScene[];
  onClose: () => void;
  onUseAsPrompt: (promptText: string) => void;
}

export function AiAssistantDrawer({
  open,
  project,
  characters,
  scenes,
  onClose,
  onUseAsPrompt,
}: AiAssistantDrawerProps) {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content: `Ready to collaborate on "${project.title}". Ask me to write a story treatment, suggest the next storyboard scene, craft detailed visual prompts, or develop a character.`,
    },
  ]);

  if (!open) return null;

  async function sendMessage(text: string) {
    const trimmed = text.trim();
    if (!trimmed || loading) return;

    const nextHistory: ChatMessage[] = [...messages, { role: "user", content: trimmed }];
    setMessages(nextHistory);
    setInput("");
    setLoading(true);

    try {
      const res = await callStudioAssistant({
        mode: "chat",
        message: trimmed,
        history: nextHistory,
        projectContext: {
          title: project.title,
          synopsis: project.synopsis,
          visualStyle: project.visualStyle,
          characters: characters.map((c) => ({
            name: c.name,
            entityType: c.entityType,
            appearancePrompt: c.appearancePrompt,
          })),
          scenes: scenes.map((s) => ({ title: s.title, prompt: s.prompt })),
        },
      });

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: res.reply || "No response returned.",
        },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: err instanceof Error ? err.message : "Assistant request failed.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <aside className="fixed inset-y-0 right-0 z-50 w-full sm:w-[400px] bg-[#12151B] border-l border-white/12 shadow-2xl flex flex-col">
      <div className="px-5 py-4 border-b border-white/8 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#E59F3E]" />
          <h2 className="text-sm font-semibold text-[#F2F4F8] font-display">
            AI Creative Assistant
          </h2>
        </div>
        <button
          type="button"
          aria-label="Close assistant"
          onClick={onClose}
          className="p-1.5 text-neutral-400 hover:text-white cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Quick Creative Prompts */}
      <div className="px-4 py-2.5 border-b border-white/8 flex items-center gap-2 overflow-x-auto">
        {[
          "Suggest the next scene",
          "Write a cinematic prompt",
          "Improve story pacing",
          "Invent a visual prop",
        ].map((suggestion) => (
          <button
            key={suggestion}
            type="button"
            onClick={() => void sendMessage(suggestion)}
            className="px-2.5 py-1 text-[11px] rounded-md bg-[#0B0D10] border border-white/10 text-neutral-300 hover:border-[#E59F3E] hover:text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            {suggestion}
          </button>
        ))}
      </div>

      {/* Conversation Thread */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`space-y-2 ${msg.role === "user" ? "pl-8" : "pr-4"}`}
          >
            <div
              className={`p-3 rounded-xl text-xs leading-relaxed whitespace-pre-wrap ${
                msg.role === "user"
                  ? "bg-[#E59F3E]/15 border border-[#E59F3E]/30 text-[#F2F4F8]"
                  : "bg-[#0B0D10] border border-white/8 text-neutral-200"
              }`}
            >
              {msg.content}
            </div>
            {msg.role === "assistant" && idx > 0 && (
              <button
                type="button"
                onClick={() => {
                  onUseAsPrompt(msg.content);
                  onClose();
                }}
                className="text-[11px] font-medium text-[#E59F3E] hover:text-[#F0AE52] cursor-pointer"
              >
                Use in Workspace Prompt
              </button>
            )}
          </div>
        ))}
        {loading && (
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-[#E59F3E]" />
            <span>Writing creative direction...</span>
          </div>
        )}
      </div>

      {/* Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void sendMessage(input);
        }}
        className="p-4 border-t border-white/8 flex items-center gap-2"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask for story ideas, prompts, scenes..."
          className="flex-1 px-3 py-2 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-[#F2F4F8] placeholder:text-neutral-500 focus:outline-none focus:border-[#E59F3E]"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          aria-label="Send message"
          className="p-2 rounded-lg bg-[#E59F3E] text-[#0B0D10] hover:bg-[#F0AE52] disabled:opacity-50 cursor-pointer"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </aside>
  );
}
