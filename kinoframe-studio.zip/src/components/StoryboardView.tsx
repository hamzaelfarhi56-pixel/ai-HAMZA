import { useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  Clapperboard,
  Film,
  Image as ImageIcon,
  Layers,
  Loader2,
  Plus,
  Sparkles,
  Trash2,
  Video,
  Wand2,
} from "lucide-react";
import {
  calculateGenerationCreditCost,
  CAMERA_MOVEMENTS,
  type CharacterEntity,
  type MediaAsset,
  type StoryboardScene,
  type StudioProject,
} from "../types/studio";
import {
  callStudioAssistant,
  pollGenerationJob,
  startImageGeneration,
  startVideoGeneration,
} from "../services/apiClient";
import {
  addTimelineClip,
  createAsset,
  createScene,
  deductUserCredits,
  deleteScene,
  refundUserCredits,
  swapSceneOrder,
  updateAssetStatus,
  updateProjectCounts,
  updateSceneDetails,
  updateSceneMedia,
} from "../services/firestoreService";
import { PipelineStatusLabel, SafeMediaImage } from "./MediaFallback";

interface StoryboardViewProps {
  uid: string;
  project: StudioProject;
  credits: number;
  scenes: StoryboardScene[];
  characters: CharacterEntity[];
  assets: MediaAsset[];
  timelineCount: number;
  onGoToTimeline: () => void;
}

export function StoryboardView({
  uid,
  project,
  credits,
  scenes,
  characters,
  assets,
  timelineCount,
  onGoToTimeline,
}: StoryboardViewProps) {
  const [storyIdea, setStoryIdea] = useState("");
  const [breakingDown, setBreakingDown] = useState(false);
  const [creatingScene, setCreatingScene] = useState(false);
  const [stageLabels, setStageLabels] = useState<Record<string, string>>({});
  const [feedback, setFeedback] = useState<{ type: "error" | "success"; text: string } | null>(
    null
  );

  async function handleStoryBreakdown(e: React.FormEvent) {
    e.preventDefault();
    if (!storyIdea.trim()) return;
    setBreakingDown(true);
    setFeedback(null);
    try {
      const res = await callStudioAssistant({
        mode: "breakdown-story",
        message: storyIdea,
        projectContext: {
          title: project.title,
          synopsis: project.synopsis,
          visualStyle: project.visualStyle,
          characters: characters.map((c) => ({
            name: c.name,
            entityType: c.entityType,
            appearancePrompt: c.appearancePrompt,
          })),
          scenes: scenes.map((s) => ({ title: s.title, prompt: s.prompt })),
        },
      });

      const data = res.data as {
        scenes?: Array<{
          title: string;
          prompt: string;
          notes: string;
          cameraMovement: string;
          durationSeconds: number;
        }>;
      };
      const newScenes = data?.scenes || [];
      if (newScenes.length === 0) {
        throw new Error("Assistant could not generate scene breakdown.");
      }

      let idx = scenes.length;
      for (const sc of newScenes) {
        await createScene({
          projectId: project.id,
          ownerId: uid,
          orderIndex: idx++,
          title: sc.title || `Scene ${idx}`,
          prompt: sc.prompt || "",
          notes: sc.notes || "",
          durationSeconds: Math.max(3, Math.min(15, Number(sc.durationSeconds || 8))),
          cameraMovement: sc.cameraMovement || CAMERA_MOVEMENTS[1],
          visualStyle: project.visualStyle,
          characterIds: characters.slice(0, 2).map((c) => c.id),
          status: "Draft",
        });
      }

      await updateProjectCounts(project.id, {
        sceneCount: scenes.length + newScenes.length,
      });
      setStoryIdea("");
      setFeedback({
        type: "success",
        text: `Added ${newScenes.length} connected scenes to your storyboard.`,
      });
    } catch (err) {
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Story breakdown failed.",
      });
    } finally {
      setBreakingDown(false);
    }
  }

  async function handleAddBlankScene() {
    setCreatingScene(true);
    try {
      await createScene({
        projectId: project.id,
        ownerId: uid,
        orderIndex: scenes.length,
        title: `Scene ${String(scenes.length + 1).padStart(2, "0")}`,
        prompt: "",
        notes: "",
        durationSeconds: 8,
        cameraMovement: CAMERA_MOVEMENTS[1],
        visualStyle: project.visualStyle,
        status: "Draft",
      });
      await updateProjectCounts(project.id, { sceneCount: scenes.length + 1 });
    } catch (err) {
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Could not add scene.",
      });
    } finally {
      setCreatingScene(false);
    }
  }

  async function handleGenerateSceneMedia(scene: StoryboardScene, kind: "image" | "video") {
    if (!scene.prompt.trim()) {
      setFeedback({ type: "error", text: `Write a prompt for "${scene.title}" first.` });
      return;
    }

    const cost = calculateGenerationCreditCost({
      kind,
      resolution: kind === "image" ? "1K" : "720p",
      durationSeconds: scene.durationSeconds,
    });

    if (credits < cost) {
      setFeedback({
        type: "error",
        text: `Insufficient credits (${credits} remaining, ${cost} needed).`,
      });
      return;
    }

    setFeedback(null);
    let deducted = false;
    let assetId = "";

    const linkedChars = characters
      .filter((c) => (scene.characterIds || []).includes(c.id))
      .map((c) => ({
        name: c.name,
        entityType: c.entityType,
        appearancePrompt: c.appearancePrompt,
        referenceImageUrl: c.referenceImageUrl,
      }));

    try {
      await deductUserCredits(uid, cost);
      deducted = true;

      await updateSceneDetails(project.id, scene.id, {
        status: "Generating",
        errorMessage: "",
      });

      const useImageToVideo = kind === "video" && scene.mediaType === "image" && Boolean(scene.mediaUrl);

      assetId = await createAsset({
        projectId: project.id,
        ownerId: uid,
        title: `${scene.title} (${kind === "image" ? "Frame" : "Clip"})`,
        assetType: kind,
        source: "generated",
        prompt: scene.prompt,
        generationMode:
          kind === "image"
            ? "text-to-image"
            : useImageToVideo
              ? "image-to-video"
              : "text-to-video",
        aspectRatio: project.aspectRatio,
        duration: kind === "video" ? `${Math.min(15, Math.max(3, scene.durationSeconds))}s` : "",
        resolution: kind === "image" ? "1K" : "720p",
        cameraMovement: scene.cameraMovement || "Static Locked",
        visualStyle: scene.visualStyle || project.visualStyle,
        characterIds: scene.characterIds || [],
        status: "Generating",
        creditCost: cost,
      });

      await updateProjectCounts(project.id, { assetCount: assets.length + 1 });

      const job =
        kind === "image"
          ? await startImageGeneration({
              prompt: scene.prompt,
              aspectRatio: project.aspectRatio,
              resolution: "1K",
              visualStyle: scene.visualStyle || project.visualStyle,
              cameraMovement: scene.cameraMovement,
              characters: linkedChars,
            })
          : await startVideoGeneration({
              mode: useImageToVideo ? "image-to-video" : "text-to-video",
              prompt: scene.prompt,
              aspectRatio: project.aspectRatio === "9:16" ? "9:16" : "16:9",
              durationSeconds: Math.min(15, Math.max(3, scene.durationSeconds)),
              resolution: "720p",
              visualStyle: scene.visualStyle || project.visualStyle,
              cameraMovement: scene.cameraMovement,
              startImageUrl: useImageToVideo ? scene.mediaUrl : undefined,
              characters: linkedChars,
            });

      setStageLabels((m) => ({ ...m, [scene.id]: job.stageLabel }));

      let lastStatus = "Generating";
      const result = await pollGenerationJob(job.jobId, (progress) => {
        setStageLabels((m) => ({ ...m, [scene.id]: progress.stageLabel }));
        if (progress.status !== lastStatus && progress.status === "Processing") {
          lastStatus = "Processing";
          void updateSceneDetails(project.id, scene.id, { status: "Processing" });
          void updateAssetStatus(project.id, assetId, { status: "Processing" });
        }
      });

      if (result.status === "Completed" && result.result?.url) {
        await updateAssetStatus(project.id, assetId, {
          status: "Completed",
          url: result.result.url,
          mimeType: result.result.mimeType,
          interactionId: result.result.interactionId || "",
        });
        await updateSceneMedia(project.id, scene.id, {
          mediaUrl: result.result.url,
          mediaType: kind,
          assetId,
          status: "Completed",
          errorMessage: "",
        });
      } else {
        throw new Error(result.errorMessage || "Scene generation failed.");
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Scene generation failed.";
      await updateSceneDetails(project.id, scene.id, {
        status: "Failed",
        errorMessage: msg,
      });
      if (assetId) {
        await updateAssetStatus(project.id, assetId, {
          status: "Failed",
          errorMessage: msg,
        });
      }
      if (deducted) await refundUserCredits(uid, cost);
      setFeedback({ type: "error", text: msg });
    }
  }

  async function handlePushSceneToTimeline(scene: StoryboardScene) {
    if (!scene.mediaUrl || scene.mediaType === "none") return;
    try {
      await addTimelineClip({
        projectId: project.id,
        ownerId: uid,
        sceneId: scene.id,
        assetId: scene.assetId || "",
        title: scene.title,
        mediaUrl: scene.mediaUrl,
        mediaType: scene.mediaType,
        orderIndex: timelineCount,
        sourceDuration: scene.durationSeconds || 6,
      });
      setFeedback({ type: "success", text: `Added "${scene.title}" to Scene Builder Timeline.` });
    } catch (err) {
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Failed to push scene to timeline.",
      });
    }
  }

  async function handlePushAllToTimeline() {
    const ready = scenes.filter((s) => s.mediaUrl && s.mediaType !== "none");
    if (ready.length === 0) {
      setFeedback({
        type: "error",
        text: "Generate or attach media to at least one scene before sending to timeline.",
      });
      return;
    }
    try {
      let idx = timelineCount;
      for (const sc of ready) {
        await addTimelineClip({
          projectId: project.id,
          ownerId: uid,
          sceneId: sc.id,
          assetId: sc.assetId || "",
          title: sc.title,
          mediaUrl: sc.mediaUrl!,
          mediaType: sc.mediaType as "image" | "video",
          orderIndex: idx++,
          sourceDuration: sc.durationSeconds || 6,
        });
      }
      onGoToTimeline();
    } catch (err) {
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Failed to assemble timeline.",
      });
    }
  }

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="pb-5 border-b border-white/8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs text-neutral-400">
            Projects / <span className="text-neutral-200">{project.title}</span> / Storyboard
          </p>
          <h1 className="text-xl sm:text-2xl font-semibold text-[#F2F4F8] font-display mt-0.5">
            Scene-by-Scene Storyboard
          </h1>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            disabled={creatingScene}
            onClick={() => void handleAddBlankScene()}
            className="px-3.5 py-2 text-xs font-medium rounded-lg bg-[#12151B] border border-white/12 text-[#F2F4F8] hover:border-white/25 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Scene</span>
          </button>
          <button
            type="button"
            onClick={() => void handlePushAllToTimeline()}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#E59F3E] text-[#0B0D10] hover:bg-[#F0AE52] inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Clapperboard className="w-3.5 h-3.5" />
            <span>Assemble in Scene Builder</span>
          </button>
        </div>
      </div>

      {/* AI Story Breakdown Bar */}
      <form
        onSubmit={(e) => void handleStoryBreakdown(e)}
        className="bg-[#12151B] border border-white/8 rounded-xl p-4 sm:p-5 flex flex-col md:flex-row gap-3 items-stretch md:items-center"
      >
        <div className="flex-1">
          <input
            type="text"
            value={storyIdea}
            onChange={(e) => setStoryIdea(e.target.value)}
            placeholder="Describe a story arc or sequence idea to auto-divide into connected storyboard scenes..."
            className="w-full px-3.5 py-2 text-xs sm:text-sm bg-[#0B0D10] border border-white/10 rounded-lg text-[#F2F4F8] placeholder:text-neutral-500 focus:outline-none focus:border-[#E59F3E]"
          />
        </div>
        <button
          type="submit"
          disabled={breakingDown || !storyIdea.trim()}
          className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#181C24] border border-[#E59F3E]/35 text-[#E59F3E] hover:border-[#E59F3E] disabled:opacity-50 inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
        >
          {breakingDown ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Wand2 className="w-3.5 h-3.5" />
          )}
          <span>{breakingDown ? "Dividing Story..." : "AI Story Breakdown"}</span>
        </button>
      </form>

      {feedback && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-4 ${
            feedback.type === "error"
              ? "bg-red-500/10 border-red-500/30 text-red-300"
              : "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
          }`}
        >
          <span>{feedback.text}</span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="underline hover:text-white cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Scene Cards List */}
      {scenes.length === 0 ? (
        <div className="bg-[#12151B] border border-white/8 rounded-xl p-12 text-center space-y-3">
          <Layers className="w-8 h-8 text-neutral-500 mx-auto" />
          <h2 className="text-base font-semibold text-[#F2F4F8] font-display">
            Your storyboard is empty
          </h2>
          <p className="text-xs text-neutral-400 max-w-md mx-auto">
            Use the AI Story Breakdown bar above to split a story concept into scenes, or add a
            scene manually.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {scenes.map((scene, index) => {
            const videoCost = calculateGenerationCreditCost({
              kind: "video",
              resolution: "720p",
              durationSeconds: scene.durationSeconds,
            });
            const isBusy = scene.status === "Generating" || scene.status === "Processing";

            return (
              <div
                key={scene.id}
                className="bg-[#12151B] border border-white/8 rounded-xl p-4 sm:p-5 grid grid-cols-1 lg:grid-cols-12 gap-5 items-start"
              >
                {/* Media Preview Frame */}
                <div className="lg:col-span-4 space-y-2">
                  <div className="aspect-video rounded-lg overflow-hidden bg-[#0B0D10] border border-white/8 relative">
                    {scene.mediaUrl && scene.mediaType === "video" ? (
                      <video
                        src={scene.mediaUrl}
                        controls
                        playsInline
                        className="w-full h-full object-cover"
                      />
                    ) : scene.mediaUrl && scene.mediaType === "image" ? (
                      <SafeMediaImage src={scene.mediaUrl} alt={scene.title} />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-neutral-600 p-4 text-center">
                        <Film className="w-6 h-6 mb-1.5" />
                        <span className="text-xs">No visual generated yet</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono tabular-nums text-neutral-400">
                      Scene {String(index + 1).padStart(2, "0")} · {scene.durationSeconds}s
                    </span>
                    <PipelineStatusLabel
                      status={scene.status}
                      stageLabel={stageLabels[scene.id]}
                    />
                  </div>
                </div>

                {/* Scene Controls & Prompt */}
                <div className="lg:col-span-8 space-y-3.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <input
                      type="text"
                      value={scene.title}
                      maxLength={140}
                      onChange={(e) =>
                        void updateSceneDetails(project.id, scene.id, { title: e.target.value })
                      }
                      className="text-base font-semibold text-[#F2F4F8] font-display bg-transparent border-b border-transparent hover:border-white/15 focus:border-[#E59F3E] focus:outline-none px-1 py-0.5 flex-1 min-w-[180px]"
                    />

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        disabled={index === 0}
                        aria-label="Move scene up"
                        onClick={() =>
                          void swapSceneOrder(project.id, scene, scenes[index - 1])
                        }
                        className="p-1.5 rounded border border-white/10 text-neutral-400 hover:text-white disabled:opacity-30 cursor-pointer"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={index === scenes.length - 1}
                        aria-label="Move scene down"
                        onClick={() =>
                          void swapSceneOrder(project.id, scene, scenes[index + 1])
                        }
                        className="p-1.5 rounded border border-white/10 text-neutral-400 hover:text-white disabled:opacity-30 cursor-pointer"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label={`Delete ${scene.title}`}
                        onClick={() => {
                          void deleteScene(project.id, scene.id);
                          void updateProjectCounts(project.id, {
                            sceneCount: Math.max(0, scenes.length - 1),
                          });
                        }}
                        className="p-1.5 rounded border border-white/10 text-neutral-400 hover:text-red-400 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <textarea
                    rows={3}
                    maxLength={3000}
                    defaultValue={scene.prompt}
                    onBlur={(e) => {
                      if (e.target.value !== scene.prompt) {
                        void updateSceneDetails(project.id, scene.id, { prompt: e.target.value });
                      }
                    }}
                    placeholder="Scene visual prompt..."
                    className="w-full px-3 py-2 text-xs sm:text-sm bg-[#0B0D10] border border-white/10 rounded-lg text-[#F2F4F8] placeholder:text-neutral-500 focus:outline-none focus:border-[#E59F3E]"
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    <select
                      value={scene.cameraMovement || CAMERA_MOVEMENTS[0]}
                      onChange={(e) =>
                        void updateSceneDetails(project.id, scene.id, {
                          cameraMovement: e.target.value,
                        })
                      }
                      className="px-2.5 py-1.5 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-neutral-200 focus:outline-none focus:border-[#E59F3E]"
                    >
                      {CAMERA_MOVEMENTS.map((cm) => (
                        <option key={cm} value={cm}>
                          {cm}
                        </option>
                      ))}
                    </select>

                    <div className="flex items-center gap-2 px-2.5 py-1.5 bg-[#0B0D10] border border-white/10 rounded-lg text-xs">
                      <span className="text-neutral-400 shrink-0">Duration</span>
                      <input
                        type="number"
                        min={3}
                        max={15}
                        value={scene.durationSeconds}
                        onChange={(e) =>
                          void updateSceneDetails(project.id, scene.id, {
                            durationSeconds: Math.max(3, Math.min(15, Number(e.target.value) || 8)),
                          })
                        }
                        className="w-full bg-transparent text-right font-mono tabular-nums text-neutral-100 focus:outline-none"
                      />
                      <span className="text-neutral-500">s</span>
                    </div>

                    <input
                      type="text"
                      defaultValue={scene.notes || ""}
                      onBlur={(e) => {
                        if (e.target.value !== (scene.notes || "")) {
                          void updateSceneDetails(project.id, scene.id, { notes: e.target.value });
                        }
                      }}
                      placeholder="Director notes..."
                      className="px-2.5 py-1.5 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-neutral-300 placeholder:text-neutral-500 focus:outline-none focus:border-[#E59F3E]"
                    />
                  </div>

                  {/* Character consistency links */}
                  {characters.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[11px] text-neutral-400 mr-1">Cast / Props:</span>
                      {characters.map((ch) => {
                        const active = (scene.characterIds || []).includes(ch.id);
                        return (
                          <button
                            key={ch.id}
                            type="button"
                            onClick={() => {
                              const current = scene.characterIds || [];
                              const next = active
                                ? current.filter((x) => x !== ch.id)
                                : [...current.slice(0, 5), ch.id];
                              void updateSceneDetails(project.id, scene.id, {
                                characterIds: next,
                              });
                            }}
                            className={`px-2 py-0.5 text-[11px] rounded border cursor-pointer ${
                              active
                                ? "bg-[#E59F3E]/15 border-[#E59F3E] text-[#F2F4F8]"
                                : "bg-[#0B0D10] border-white/10 text-neutral-400 hover:text-neutral-200"
                            }`}
                          >
                            {ch.name}
                          </button>
                        );
                      })}
                    </div>
                  )}

                  {scene.errorMessage && (
                    <p className="text-xs text-red-400">{scene.errorMessage}</p>
                  )}

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/6">
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => void handleGenerateSceneMedia(scene, "image")}
                        className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#0B0D10] border border-white/12 text-neutral-200 hover:border-[#E59F3E] disabled:opacity-50 inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <ImageIcon className="w-3.5 h-3.5 text-[#E59F3E]" />
                        <span>Generate Frame (4 cr)</span>
                      </button>
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => void handleGenerateSceneMedia(scene, "video")}
                        className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#E59F3E] text-[#0B0D10] hover:bg-[#F0AE52] disabled:opacity-50 inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        {isBusy ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Video className="w-3.5 h-3.5" />
                        )}
                        <span>
                          {scene.mediaType === "image" && scene.mediaUrl
                            ? `Animate Scene (${videoCost} cr)`
                            : `Generate Video (${videoCost} cr)`}
                        </span>
                      </button>
                    </div>

                    {scene.mediaUrl && scene.mediaType !== "none" && (
                      <button
                        type="button"
                        onClick={() => void handlePushSceneToTimeline(scene)}
                        className="text-xs font-medium text-[#E59F3E] hover:text-[#F0AE52] inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Add to Timeline</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
