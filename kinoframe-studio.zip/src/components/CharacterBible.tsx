import { useRef, useState } from "react";
import { ArrowRight, Loader2, Plus, Sparkles, Trash2, Upload, Users, Wand2 } from "lucide-react";
import type { CharacterEntity, StudioProject } from "../types/studio";
import {
  callStudioAssistant,
  pollGenerationJob,
  startImageGeneration,
  uploadReferenceFile,
} from "../services/apiClient";
import {
  createAsset,
  createCharacter,
  deductUserCredits,
  deleteCharacter,
  refundUserCredits,
  updateCharacter,
} from "../services/firestoreService";
import { CREDIT_COSTS } from "../types/studio";
import { SafeMediaImage } from "./MediaFallback";

interface CharacterBibleProps {
  uid: string;
  project: StudioProject;
  credits: number;
  characters: CharacterEntity[];
  onUseCharacterInWorkspace: (characterId: string) => void;
}

export function CharacterBible({
  uid,
  project,
  credits,
  characters,
  onUseCharacterInWorkspace,
}: CharacterBibleProps) {
  const [name, setName] = useState("");
  const [entityType, setEntityType] = useState<"character" | "object" | "location">("character");
  const [appearancePrompt, setAppearancePrompt] = useState("");
  const [tagsText, setTagsText] = useState("");
  const [referenceImageUrl, setReferenceImageUrl] = useState("");
  const [aiIdea, setAiIdea] = useState("");

  const [developing, setDeveloping] = useState(false);
  const [generatingPortrait, setGeneratingPortrait] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: "error" | "success"; text: string } | null>(
    null
  );

  const fileRef = useRef<HTMLInputElement>(null);

  function resetForm() {
    setEditingId(null);
    setName("");
    setEntityType("character");
    setAppearancePrompt("");
    setTagsText("");
    setReferenceImageUrl("");
  }

  function loadForEdit(ch: CharacterEntity) {
    setEditingId(ch.id);
    setName(ch.name);
    setEntityType(ch.entityType);
    setAppearancePrompt(ch.appearancePrompt);
    setTagsText((ch.tags || []).join(", "));
    setReferenceImageUrl(ch.referenceImageUrl || "");
  }

  async function handleUploadPortrait(file: File | null) {
    if (!file) return;
    setUploading(true);
    setFeedback(null);
    try {
      const uploaded = await uploadReferenceFile(file);
      setReferenceImageUrl(uploaded.url);
      await createAsset({
        projectId: project.id,
        ownerId: uid,
        title: `${name || "Character"} Reference`,
        assetType: "image",
        source: "upload",
        url: uploaded.url,
        mimeType: uploaded.mimeType,
        generationMode: "upload",
        aspectRatio: "1:1",
        status: "Completed",
        creditCost: 0,
      });
    } catch (err) {
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Could not upload reference portrait.",
      });
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function handleAiDevelop() {
    if (!aiIdea.trim()) return;
    setDeveloping(true);
    setFeedback(null);
    try {
      const res = await callStudioAssistant({
        mode: "develop-character",
        message: aiIdea,
        projectContext: {
          title: project.title,
          synopsis: project.synopsis,
          visualStyle: project.visualStyle,
        },
      });
      const data = res.data as {
        name?: string;
        entityType?: string;
        appearancePrompt?: string;
        tags?: string[];
      };
      if (data.name) setName(data.name);
      if (
        data.entityType === "character" ||
        data.entityType === "object" ||
        data.entityType === "location"
      ) {
        setEntityType(data.entityType);
      }
      if (data.appearancePrompt) setAppearancePrompt(data.appearancePrompt);
      if (Array.isArray(data.tags)) setTagsText(data.tags.slice(0, 6).join(", "));
      setAiIdea("");
      setFeedback({ type: "success", text: "Character consistency sheet drafted by AI." });
    } catch (err) {
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Could not develop character.",
      });
    } finally {
      setDeveloping(false);
    }
  }

  async function handleGeneratePortrait() {
    if (!appearancePrompt.trim()) {
      setFeedback({
        type: "error",
        text: "Describe the character or object appearance before generating a portrait.",
      });
      return;
    }
    if (credits < CREDIT_COSTS.imageStandard) {
      setFeedback({ type: "error", text: "Insufficient credits for reference portrait (4 cr)." });
      return;
    }

    setGeneratingPortrait(true);
    setFeedback(null);
    let deducted = false;
    try {
      await deductUserCredits(uid, CREDIT_COSTS.imageStandard);
      deducted = true;
      const job = await startImageGeneration({
        prompt: `Studio character/object reference sheet portrait on neutral dark backdrop: ${appearancePrompt}`,
        aspectRatio: "1:1",
        resolution: "1K",
        visualStyle: project.visualStyle,
      });
      const result = await pollGenerationJob(job.jobId);
      if (result.status === "Completed" && result.result?.url) {
        setReferenceImageUrl(result.result.url);
        await createAsset({
          projectId: project.id,
          ownerId: uid,
          title: `${name || "Subject"} Reference Portrait`,
          assetType: "image",
          source: "generated",
          url: result.result.url,
          mimeType: result.result.mimeType,
          prompt: appearancePrompt,
          generationMode: "text-to-image",
          aspectRatio: "1:1",
          resolution: "1K",
          visualStyle: project.visualStyle,
          status: "Completed",
          creditCost: CREDIT_COSTS.imageStandard,
        });
        setFeedback({ type: "success", text: "Reference portrait generated and attached." });
      } else {
        throw new Error(result.errorMessage || "Reference portrait generation failed.");
      }
    } catch (err) {
      if (deducted) await refundUserCredits(uid, CREDIT_COSTS.imageStandard);
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Portrait generation failed.",
      });
    } finally {
      setGeneratingPortrait(false);
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !appearancePrompt.trim()) return;
    setSaving(true);
    setFeedback(null);
    const parsedTags = tagsText
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean)
      .slice(0, 6);

    try {
      if (editingId) {
        await updateCharacter(project.id, editingId, {
          name: name.trim(),
          entityType,
          appearancePrompt: appearancePrompt.trim(),
          referenceImageUrl,
          tags: parsedTags,
        });
        setFeedback({ type: "success", text: `Updated "${name.trim()}".` });
      } else {
        await createCharacter({
          projectId: project.id,
          ownerId: uid,
          name: name.trim(),
          entityType,
          appearancePrompt: appearancePrompt.trim(),
          referenceImageUrl,
          tags: parsedTags,
        });
        setFeedback({ type: "success", text: `Added "${name.trim()}" to Consistency Bible.` });
      }
      resetForm();
    } catch (err) {
      setFeedback({
        type: "error",
        text: err instanceof Error ? err.message : "Failed to save character.",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 py-6 space-y-6">
      <div className="pb-5 border-b border-white/8 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs text-neutral-400">
            Projects / <span className="text-neutral-200">{project.title}</span> / Consistency
            Bible
          </p>
          <h1 className="text-xl sm:text-2xl font-semibold text-[#F2F4F8] font-display mt-0.5">
            Characters, Objects &amp; Locations
          </h1>
        </div>
        <p className="text-xs text-neutral-400 max-w-md">
          Define recurring subjects once so their facial features, wardrobe, or prop details stay
          consistent across every storyboard scene and generated video.
        </p>
      </div>

      {feedback && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-4 ${
            feedback.type === "error"
              ? "bg-red-500/10 border-red-500/30 text-red-300"
              : "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
          }`}
        >
          <span>{feedback.text}</span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="underline hover:text-white cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Character / Object Builder */}
        <section className="lg:col-span-5 bg-[#12151B] border border-white/8 rounded-xl p-5 space-y-5">
          <div className="p-3.5 rounded-lg bg-[#0B0D10] border border-white/8 space-y-2.5">
            <label className="text-xs font-medium text-neutral-300 block">
              AI Character &amp; Prop Architect
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={aiIdea}
                onChange={(e) => setAiIdea(e.target.value)}
                placeholder="e.g., Tired orbital courier with scarred visor..."
                className="flex-1 px-3 py-1.5 text-xs bg-[#12151B] border border-white/10 rounded-lg text-[#F2F4F8] placeholder:text-neutral-500 focus:outline-none focus:border-[#E59F3E]"
              />
              <button
                type="button"
                disabled={developing || !aiIdea.trim()}
                onClick={() => void handleAiDevelop()}
                className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#181C24] border border-white/12 text-[#E59F3E] hover:border-[#E59F3E] disabled:opacity-50 inline-flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                {developing ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Wand2 className="w-3.5 h-3.5" />
                )}
                <span>Draft</span>
              </button>
            </div>
          </div>

          <form onSubmit={(e) => void handleSave(e)} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs text-neutral-300 block">Name</label>
                <input
                  type="text"
                  required
                  maxLength={80}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., Kael Mercer"
                  className="w-full px-3 py-2 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-[#F2F4F8] focus:outline-none focus:border-[#E59F3E]"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs text-neutral-300 block">Entity Type</label>
                <select
                  value={entityType}
                  onChange={(e) =>
                    setEntityType(e.target.value as "character" | "object" | "location")
                  }
                  className="w-full px-3 py-2 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-[#F2F4F8] focus:outline-none focus:border-[#E59F3E]"
                >
                  <option value="character">Character</option>
                  <option value="object">Object / Prop</option>
                  <option value="location">Location</option>
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs text-neutral-300 block">
                Visual Continuity Description
              </label>
              <textarea
                rows={4}
                required
                maxLength={1500}
                value={appearancePrompt}
                onChange={(e) => setAppearancePrompt(e.target.value)}
                placeholder="Specify exact age, hair, clothing textures, color palette, materials, and lighting cues..."
                className="w-full px-3 py-2 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-[#F2F4F8] placeholder:text-neutral-500 focus:outline-none focus:border-[#E59F3E] leading-relaxed"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs text-neutral-300 block">
                Reference Portrait / Sheet
              </label>
              <div className="flex items-center gap-3">
                <div className="w-16 h-16 rounded-lg overflow-hidden bg-[#0B0D10] border border-white/10 shrink-0">
                  <SafeMediaImage src={referenceImageUrl} alt={name || "Reference"} />
                </div>
                <div className="flex flex-wrap gap-2">
                  <input
                    ref={fileRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    className="hidden"
                    onChange={(e) => void handleUploadPortrait(e.target.files?.[0] || null)}
                  />
                  <button
                    type="button"
                    disabled={uploading}
                    onClick={() => fileRef.current?.click()}
                    className="px-3 py-1.5 text-xs rounded-lg bg-[#0B0D10] border border-white/12 text-neutral-200 hover:border-white/30 inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploading ? "Uploading..." : "Upload Image"}</span>
                  </button>
                  <button
                    type="button"
                    disabled={generatingPortrait}
                    onClick={() => void handleGeneratePortrait()}
                    className="px-3 py-1.5 text-xs rounded-lg bg-[#0B0D10] border border-[#E59F3E]/35 text-[#E59F3E] hover:border-[#E59F3E] inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    {generatingPortrait ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Sparkles className="w-3.5 h-3.5" />
                    )}
                    <span>Generate Portrait (4 cr)</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs text-neutral-300 block">Tags (comma separated)</label>
              <input
                type="text"
                value={tagsText}
                onChange={(e) => setTagsText(e.target.value)}
                placeholder="protagonist, wool coat, noir"
                className="w-full px-3 py-2 text-xs bg-[#0B0D10] border border-white/10 rounded-lg text-[#F2F4F8] focus:outline-none focus:border-[#E59F3E]"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              {editingId && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-3.5 py-2 text-xs rounded-lg border border-white/12 text-neutral-300 hover:text-white cursor-pointer"
                >
                  Cancel Edit
                </button>
              )}
              <button
                type="submit"
                disabled={saving || !name.trim() || !appearancePrompt.trim()}
                className="px-5 py-2 text-xs font-semibold rounded-lg bg-[#E59F3E] text-[#0B0D10] hover:bg-[#F0AE52] disabled:opacity-50 inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{editingId ? "Save Changes" : "Add to Bible"}</span>
              </button>
            </div>
          </form>
        </section>

        {/* Right: Saved Consistency Library */}
        <section className="lg:col-span-7 space-y-4">
          {characters.length === 0 ? (
            <div className="bg-[#12151B] border border-white/8 rounded-xl p-10 text-center space-y-2">
              <Users className="w-7 h-7 text-neutral-500 mx-auto" />
              <h2 className="text-sm font-semibold text-[#F2F4F8] font-display">
                No characters or objects yet
              </h2>
              <p className="text-xs text-neutral-400 max-w-sm mx-auto">
                Add your hero, signature props, or key locations on the left to lock visual
                continuity across scenes.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {characters.map((ch) => (
                <div
                  key={ch.id}
                  className="bg-[#12151B] border border-white/8 rounded-xl p-4 flex flex-col justify-between space-y-4"
                >
                  <div className="flex items-start gap-3.5">
                    <div className="w-20 h-20 rounded-lg overflow-hidden bg-[#0B0D10] border border-white/8 shrink-0">
                      <SafeMediaImage src={ch.referenceImageUrl} alt={ch.name} />
                    </div>
                    <div className="min-w-0 flex-1 space-y-1">
                      <p className="text-[11px] text-neutral-400 capitalize">
                        {ch.entityType}
                        {ch.tags && ch.tags.length > 0 ? ` · ${ch.tags.join(", ")}` : ""}
                      </p>
                      <h3 className="text-sm font-semibold text-[#F2F4F8] font-display truncate">
                        {ch.name}
                      </h3>
                      <p className="text-xs text-neutral-400 line-clamp-3 leading-relaxed">
                        {ch.appearancePrompt}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-3 border-t border-white/6">
                    <button
                      type="button"
                      onClick={() => onUseCharacterInWorkspace(ch.id)}
                      className="text-xs font-semibold text-[#E59F3E] hover:text-[#F0AE52] inline-flex items-center gap-1 cursor-pointer"
                    >
                      <span>Use in Workspace</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => loadForEdit(ch)}
                        className="text-xs text-neutral-400 hover:text-white cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        aria-label={`Delete ${ch.name}`}
                        onClick={() => void deleteCharacter(project.id, ch.id)}
                        className="p-1 text-neutral-500 hover:text-red-400 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
