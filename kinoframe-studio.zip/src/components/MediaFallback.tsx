import { useState } from "react";
import { AlertCircle, CheckCircle2, Film, Loader2 } from "lucide-react";
import type { SceneStatus } from "../types/studio";

export function SafeMediaImage({
  src,
  alt,
  className = "w-full h-full object-cover",
}: {
  src?: string;
  alt: string;
  className?: string;
}) {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return (
      <div className="w-full h-full bg-gradient-to-br from-[#181C24] via-[#12151B] to-[#0B0D10] flex flex-col items-center justify-center p-4 text-neutral-500">
        <Film className="w-6 h-6 mb-2 text-neutral-600" />
        <span className="text-xs text-center text-neutral-500 line-clamp-2">{alt}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}

export function PipelineStatusLabel({
  status,
  stageLabel,
}: {
  status: SceneStatus;
  stageLabel?: string;
}) {
  if (status === "Completed") {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-400 whitespace-nowrap">
        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
        <span>Completed</span>
      </span>
    );
  }

  if (status === "Generating" || status === "Processing") {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#E59F3E] whitespace-nowrap">
        <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
        <span>{stageLabel || status}</span>
      </span>
    );
  }

  if (status === "Failed") {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-red-400 whitespace-nowrap">
        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
        <span>Failed</span>
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-neutral-400 whitespace-nowrap">
      <span>Draft</span>
    </span>
  );
}
