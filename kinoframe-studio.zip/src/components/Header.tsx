import { useState, useRef, useEffect } from "react";
import { LogOut, Plus, Sparkles, User as UserIcon } from "lucide-react";
import type { User } from "firebase/auth";
import type { AspectRatio, UserProfile } from "../types/studio";
import { VISUAL_STYLES } from "../types/studio";

export type StudioView = "home" | "workspace" | "storyboard" | "timeline" | "characters";

interface HeaderProps {
  user: User | null;
  profile: UserProfile | null;
  activeView: StudioView;
  hasActiveProject: boolean;
  onNavigate: (view: StudioView) => void;
  onSignIn: () => void;
  onSignOut: () => void;
  onAddCredits: () => void;
  onUpdateDefaults: (aspectRatio: AspectRatio, style: string) => void;
  onToggleAssistant: () => void;
}

export function Header({
  user,
  profile,
  activeView,
  hasActiveProject,
  onNavigate,
  onSignIn,
  onSignOut,
  onAddCredits,
  onUpdateDefaults,
  onToggleAssistant,
}: HeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleOutside(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    }
    if (menuOpen) {
      document.addEventListener("mousedown", handleOutside);
    }
    return () => document.removeEventListener("mousedown", handleOutside);
  }, [menuOpen]);

  const navItems: Array<{ id: StudioView; label: string }> = hasActiveProject
    ? [
        { id: "home", label: "Projects" },
        { id: "workspace", label: "Workspace" },
        { id: "storyboard", label: "Storyboard" },
        { id: "timeline", label: "Scene Builder" },
        { id: "characters", label: "Characters" },
      ]
    : [{ id: "home", label: "Projects" }];

  return (
    <header className="sticky top-0 z-40 bg-[#0B0D10]/95 backdrop-blur-md border-b border-white/8">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <button
          type="button"
          onClick={() => onNavigate("home")}
          className="text-lg font-semibold tracking-tight text-[#F2F4F8] font-display whitespace-nowrap shrink-0 cursor-pointer hover:text-white transition-colors"
        >
          KinoFrame
        </button>

        {/* Zone 2: Clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium overflow-x-auto">
          {navItems.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={`py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer border-b-2 ${
                  isActive
                    ? "text-[#F2F4F8] border-[#E59F3E]"
                    : "text-neutral-400 border-transparent hover:text-neutral-200"
                }`}
              >
                {item.label}
              </button>
            );
          })}
          {user && hasActiveProject && (
            <button
              type="button"
              onClick={onToggleAssistant}
              className="py-1 whitespace-nowrap shrink-0 text-neutral-400 hover:text-[#E59F3E] transition-colors cursor-pointer border-b-2 border-transparent inline-flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Assistant</span>
            </button>
          )}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="relative shrink-0" ref={menuRef}>
          {!user ? (
            <button
              type="button"
              onClick={onSignIn}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#E59F3E] text-[#0B0D10] hover:bg-[#F0AE52] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Sign In with Google
            </button>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setMenuOpen((v) => !v)}
                className="px-3.5 py-1.5 text-xs font-medium rounded-lg bg-[#161922] border border-white/10 hover:border-white/20 text-[#F2F4F8] transition-colors whitespace-nowrap shrink-0 cursor-pointer inline-flex items-center gap-2.5"
              >
                <span className="font-mono tabular-nums text-[#E59F3E] font-semibold">
                  {profile ? `${profile.credits} cr` : "— cr"}
                </span>
                <span className="text-neutral-600" aria-hidden="true">
                  /
                </span>
                <span className="max-w-[110px] truncate text-neutral-200">
                  {profile?.displayName || user.displayName || "Account"}
                </span>
              </button>

              {menuOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-[#12151B] border border-white/12 rounded-xl shadow-2xl p-4 space-y-4 z-50">
                  <div className="flex items-start gap-3 pb-3 border-b border-white/8">
                    <div className="w-9 h-9 rounded-lg bg-[#1B1F29] flex items-center justify-center shrink-0 text-neutral-300">
                      <UserIcon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-[#F2F4F8] truncate">
                        {profile?.displayName || user.displayName}
                      </p>
                      <p className="text-xs text-neutral-400 truncate">{user.email}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-neutral-400">Remaining Credits</span>
                      <span className="font-mono tabular-nums text-sm font-semibold text-[#E59F3E]">
                        {profile?.credits ?? 0} cr
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-neutral-400">Completed Generations</span>
                      <span className="font-mono tabular-nums text-neutral-200">
                        {profile?.totalGenerated ?? 0}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        onAddCredits();
                      }}
                      className="w-full mt-1 px-3 py-2 text-xs font-medium rounded-lg bg-[#1B1F29] hover:bg-[#232836] text-[#E59F3E] border border-[#E59F3E]/25 transition-colors inline-flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add 150 Studio Credits</span>
                    </button>
                  </div>

                  <div className="pt-3 border-t border-white/8 space-y-2.5">
                    <p className="text-xs font-medium text-neutral-400">Default Studio Settings</p>
                    <div className="grid grid-cols-2 gap-2">
                      <select
                        aria-label="Default Aspect Ratio"
                        value={profile?.defaultAspectRatio || "16:9"}
                        onChange={(e) =>
                          onUpdateDefaults(
                            e.target.value as AspectRatio,
                            profile?.defaultStyle || VISUAL_STYLES[0]
                          )
                        }
                        className="bg-[#0B0D10] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-neutral-200 focus:outline-none focus:border-[#E59F3E]"
                      >
                        <option value="16:9">16:9 Wide</option>
                        <option value="9:16">9:16 Vertical</option>
                        <option value="1:1">1:1 Square</option>
                        <option value="4:3">4:3 Classic</option>
                      </select>
                      <select
                        aria-label="Default Visual Style"
                        value={profile?.defaultStyle || VISUAL_STYLES[0]}
                        onChange={(e) =>
                          onUpdateDefaults(
                            profile?.defaultAspectRatio || "16:9",
                            e.target.value
                          )
                        }
                        className="bg-[#0B0D10] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-neutral-200 focus:outline-none focus:border-[#E59F3E]"
                      >
                        {VISUAL_STYLES.map((st) => (
                          <option key={st} value={st}>
                            {st}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      onSignOut();
                    }}
                    className="w-full px-3 py-2 text-xs font-medium rounded-lg border border-white/10 text-neutral-300 hover:text-white hover:bg-white/5 transition-colors inline-flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Mobile navigation strip when inside a project */}
      {hasActiveProject && (
        <div className="md:hidden border-t border-white/8 px-4 py-2 flex items-center gap-4 overflow-x-auto text-xs font-medium">
          {navItems.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              className={`whitespace-nowrap shrink-0 py-1 ${
                activeView === item.id ? "text-[#E59F3E]" : "text-neutral-400"
              }`}
            >
              {item.label}
            </button>
          ))}
          {user && (
            <button
              type="button"
              onClick={onToggleAssistant}
              className="whitespace-nowrap shrink-0 py-1 text-neutral-300"
            >
              Assistant
            </button>
          )}
        </div>
      )}
    </header>
  );
}
