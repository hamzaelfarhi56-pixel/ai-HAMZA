import { auth } from "../firebase";
import type { PipelineStatus } from "../types/studio";

async function getAuthHeaders(): Promise<HeadersInit> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error("Please sign in to perform studio operations.");
  }
  const token = await user.getIdToken();
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
  };
}

export async function uploadReferenceFile(file: File): Promise<{
  url: string;
  mimeType: string;
  size: number;
  name: string;
}> {
  const headers = await getAuthHeaders();
  const dataBase64 = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Failed to read selected file."));
    reader.readAsDataURL(file);
  });

  const res = await fetch("/api/storage/upload", {
    method: "POST",
    headers,
    body: JSON.stringify({
      mimeType: file.type,
      dataBase64,
      originalName: file.name,
    }),
  });

  const payload = (await res.json()) as {
    url?: string;
    mimeType?: string;
    size?: number;
    name?: string;
    error?: string;
  };
  if (!res.ok || !payload.url) {
    throw new Error(payload.error || "Upload failed.");
  }
  return {
    url: payload.url,
    mimeType: payload.mimeType || file.type,
    size: payload.size || file.size,
    name: payload.name || file.name,
  };
}

export interface JobPollResult {
  id: string;
  kind: "image" | "video";
  status: PipelineStatus;
  stageLabel: string;
  result?: {
    url: string;
    mimeType: string;
    interactionId?: string;
    promptUsed?: string;
  };
  errorMessage?: string;
}

export async function startImageGeneration(body: {
  prompt: string;
  aspectRatio: string;
  resolution: string;
  visualStyle?: string;
  cameraMovement?: string;
  referenceUrls?: string[];
  characters?: Array<{
    name: string;
    entityType: string;
    appearancePrompt: string;
    referenceImageUrl?: string;
  }>;
}): Promise<{ jobId: string; status: PipelineStatus; stageLabel: string }> {
  const headers = await getAuthHeaders();
  const res = await fetch("/api/ai/generate-image", {
    method: "POST",
    headers,
    body: JSON.stringify(body),
  });
  const data = (await res.json()) as {
    jobId?: string;
    status?: PipelineStatus;
    stageLabel?: string;
    error?: string;
  };
  if (!res.ok || !data.jobId) {
    throw new Error(data.error || "Could not start image generation.");
  }
  return {
    jobId: data.jobId,
    status: data.status || "Generating",
    stageLabel: data.stageLabel || "Generating...",
  };
}

export async function startVideoGeneration(body: {
  mode: "text-to-video" | "image-to-video" | "keyframe-motion" | "video-edit";
  prompt: string;
  aspectRatio: string;
  durationSeconds: number;
  resolution: string;
  visualStyle?: string;
  cameraMovement?: string;
  startImageUrl?: string;
  endImageUrl?: string;
  referenceVideoUrl?: string;
  referenceUrls?: string[];
  characters?: Array<{
    name: string;
    entityType: string;
    appearancePrompt: string;
    referenceImageUrl?: string;
  }>;
  previousInteractionId?: string;
}): Promise<{ jobId: string; status: PipelineStatus; stageLabel: string }> {
  const headers = await getAuthHeaders();
  const res = await fetch("/api/ai/generate-video", {
    method: "POST",
    headers,
    body: JSON.stringify(body),
  });
  const data = (await res.json()) as {
    jobId?: string;
    status?: PipelineStatus;
    stageLabel?: string;
    error?: string;
  };
  if (!res.ok || !data.jobId) {
    throw new Error(data.error || "Could not start video generation.");
  }
  return {
    jobId: data.jobId,
    status: data.status || "Generating",
    stageLabel: data.stageLabel || "Generating...",
  };
}

export async function pollGenerationJob(
  jobId: string,
  onProgress?: (job: JobPollResult) => void
): Promise<JobPollResult> {
  const headers = await getAuthHeaders();
  const maxPolls = 180; // up to ~6 minutes for 4K video

  for (let i = 0; i < maxPolls; i++) {
    const res = await fetch(`/api/ai/jobs/${encodeURIComponent(jobId)}`, {
      method: "GET",
      headers,
    });
    const data = (await res.json()) as JobPollResult & { error?: string };
    if (!res.ok) {
      throw new Error(data.error || "Unable to read generation status.");
    }

    onProgress?.(data);

    if (data.status === "Completed" || data.status === "Failed") {
      return data;
    }

    await new Promise((resolve) => setTimeout(resolve, 2000));
  }

  throw new Error("Generation job timed out while waiting for completion.");
}

export async function callStudioAssistant(body: {
  mode: "chat" | "breakdown-story" | "develop-character" | "enhance-prompt";
  message: string;
  projectContext?: {
    title?: string;
    synopsis?: string;
    visualStyle?: string;
    characters?: Array<{ name: string; entityType: string; appearancePrompt: string }>;
    scenes?: Array<{ title: string; prompt: string }>;
  };
  history?: Array<{ role: "user" | "assistant"; content: string }>;
}): Promise<{
  mode: string;
  reply?: string;
  data?: Record<string, unknown>;
}> {
  const headers = await getAuthHeaders();
  const res = await fetch("/api/ai/assistant", {
    method: "POST",
    headers,
    body: JSON.stringify(body),
  });
  const data = (await res.json()) as {
    mode?: string;
    reply?: string;
    data?: Record<string, unknown>;
    error?: string;
  };
  if (!res.ok) {
    throw new Error(data.error || "Assistant request failed.");
  }
  return {
    mode: data.mode || body.mode,
    reply: data.reply,
    data: data.data,
  };
}
