import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
  type Unsubscribe,
} from "firebase/firestore";
import type { User } from "firebase/auth";
import { db, handleFirestoreError, OperationType } from "../firebase";
import type {
  AspectRatio,
  CharacterEntity,
  GenerationMode,
  MediaAsset,
  PipelineStatus,
  SceneStatus,
  ShowcaseTemplate,
  StoryboardScene,
  StudioProject,
  TimelineClip,
  TransitionType,
  UserProfile,
} from "../types/studio";

export function makeId(prefix: string): string {
  const rand = crypto.randomUUID().replace(/-/g, "").slice(0, 16);
  return `${prefix}_${rand}`;
}

function clampStr(val: string | undefined, max: number): string {
  return (val || "").slice(0, max);
}

// ==========================================
// User Profile & Credits Wallet
// ==========================================

export async function ensureUserProfile(user: User): Promise<void> {
  const path = `users/${user.uid}`;
  const ref = doc(db, "users", user.uid);
  try {
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        uid: user.uid,
        email: clampStr(user.email || "creator@kinoframe.studio", 254),
        displayName: clampStr(user.displayName || user.email?.split("@")[0] || "Director", 100),
        photoURL: clampStr(user.photoURL || "", 1024),
        credits: 250,
        totalGenerated: 0,
        defaultAspectRatio: "16:9",
        defaultStyle: "Anamorphic 35mm",
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

export function subscribeToUserProfile(
  uid: string,
  onData: (profile: UserProfile | null) => void
): Unsubscribe {
  const path = `users/${uid}`;
  return onSnapshot(
    doc(db, "users", uid),
    (snap) => {
      onData(snap.exists() ? (snap.data() as UserProfile) : null);
    },
    (err) => {
      handleFirestoreError(err, OperationType.GET, path);
    }
  );
}

export async function updateUserSettings(
  uid: string,
  patch: {
    displayName?: string;
    defaultAspectRatio?: AspectRatio;
    defaultStyle?: string;
  }
): Promise<void> {
  const path = `users/${uid}`;
  try {
    const clean: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (patch.displayName !== undefined) {
      clean.displayName = clampStr(patch.displayName.trim() || "Director", 100);
    }
    if (patch.defaultAspectRatio !== undefined) {
      clean.defaultAspectRatio = patch.defaultAspectRatio;
    }
    if (patch.defaultStyle !== undefined) {
      clean.defaultStyle = clampStr(patch.defaultStyle, 80);
    }
    await updateDoc(doc(db, "users", uid), clean);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function deductUserCredits(uid: string, amount: number): Promise<void> {
  const path = `users/${uid}`;
  const ref = doc(db, "users", uid);
  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) {
        throw new Error("User profile not found.");
      }
      const currentCredits = Number(snap.data().credits || 0);
      const currentTotal = Number(snap.data().totalGenerated || 0);
      if (currentCredits < amount) {
        throw new Error(`Insufficient credits (${currentCredits} remaining, ${amount} required).`);
      }
      tx.update(ref, {
        credits: currentCredits - amount,
        totalGenerated: currentTotal + 1,
        updatedAt: serverTimestamp(),
      });
    });
  } catch (err) {
    if (err instanceof Error && err.message.startsWith("Insufficient credits")) {
      throw err;
    }
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function refundUserCredits(uid: string, amount: number): Promise<void> {
  const path = `users/${uid}`;
  const ref = doc(db, "users", uid);
  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const currentCredits = Number(snap.data().credits || 0);
      const currentTotal = Number(snap.data().totalGenerated || 0);
      const nextCredits = Math.min(10000, currentCredits + Math.min(250, amount));
      tx.update(ref, {
        credits: nextCredits,
        totalGenerated: Math.max(0, currentTotal - 1),
        updatedAt: serverTimestamp(),
      });
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function addStudioCredits(uid: string, amount = 150): Promise<void> {
  const path = `users/${uid}`;
  const ref = doc(db, "users", uid);
  try {
    await runTransaction(db, async (tx) => {
      const snap = await tx.get(ref);
      if (!snap.exists()) return;
      const currentCredits = Number(snap.data().credits || 0);
      const currentTotal = Number(snap.data().totalGenerated || 0);
      const safeAdd = Math.min(250, Math.max(1, amount));
      tx.update(ref, {
        credits: Math.min(10000, currentCredits + safeAdd),
        totalGenerated: currentTotal,
        updatedAt: serverTimestamp(),
      });
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

// ==========================================
// Studio Projects
// ==========================================

export function subscribeToProjects(
  ownerId: string,
  onData: (projects: StudioProject[]) => void
): Unsubscribe {
  const path = "projects";
  const q = query(
    collection(db, "projects"),
    where("ownerId", "==", ownerId),
    orderBy("updatedAt", "desc")
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => d.data() as StudioProject));
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export function subscribeToProject(
  projectId: string,
  onData: (project: StudioProject | null) => void
): Unsubscribe {
  const path = `projects/${projectId}`;
  return onSnapshot(
    doc(db, "projects", projectId),
    (snap) => {
      onData(snap.exists() ? (snap.data() as StudioProject) : null);
    },
    (err) => {
      handleFirestoreError(err, OperationType.GET, path);
    }
  );
}

export async function createProject(params: {
  ownerId: string;
  title: string;
  synopsis?: string;
  genre?: string;
  visualStyle: string;
  aspectRatio: AspectRatio;
  thumbnailUrl?: string;
}): Promise<string> {
  const id = makeId("proj");
  const path = `projects/${id}`;
  try {
    await setDoc(doc(db, "projects", id), {
      id,
      ownerId: params.ownerId,
      title: clampStr(params.title.trim() || "Untitled Film", 120),
      synopsis: clampStr(params.synopsis || "", 2000),
      genre: clampStr(params.genre || "Cinema", 60),
      visualStyle: clampStr(params.visualStyle || "Anamorphic 35mm", 80),
      aspectRatio: params.aspectRatio,
      thumbnailUrl: clampStr(params.thumbnailUrl || "", 1024),
      sceneCount: 0,
      assetCount: 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function createProjectFromTemplate(
  ownerId: string,
  template: ShowcaseTemplate
): Promise<string> {
  const projectId = await createProject({
    ownerId,
    title: template.title,
    synopsis: template.synopsis,
    genre: template.genre,
    visualStyle: template.visualStyle,
    aspectRatio: template.aspectRatio,
    thumbnailUrl: template.thumbnailUrl,
  });

  // Seed characters & scenes sequentially to guarantee parent exists in rules
  const charIds: string[] = [];
  for (const ch of template.starterCharacters) {
    const cid = await createCharacter({
      projectId,
      ownerId,
      name: ch.name,
      entityType: ch.entityType,
      appearancePrompt: ch.appearancePrompt,
      referenceImageUrl: ch.referenceImageUrl,
      tags: ch.tags,
    });
    charIds.push(cid);
  }

  let sceneIdx = 0;
  for (const sc of template.starterScenes) {
    let assetId = "";
    if (sc.mediaUrl) {
      assetId = await createAsset({
        projectId,
        ownerId,
        title: `${sc.title} (Reference Still)`,
        assetType: "image",
        source: "upload",
        url: sc.mediaUrl,
        mimeType: "image/jpeg",
        prompt: sc.prompt,
        generationMode: "upload",
        aspectRatio: template.aspectRatio,
        visualStyle: template.visualStyle,
        cameraMovement: sc.cameraMovement,
        characterIds: charIds,
        status: "Completed",
        creditCost: 0,
      });
    }
    await createScene({
      projectId,
      ownerId,
      orderIndex: sceneIdx++,
      title: sc.title,
      prompt: sc.prompt,
      notes: sc.notes,
      mediaUrl: sc.mediaUrl || "",
      mediaType: sc.mediaType,
      assetId,
      durationSeconds: sc.durationSeconds,
      cameraMovement: sc.cameraMovement,
      visualStyle: template.visualStyle,
      characterIds: charIds,
      status: sc.mediaUrl ? "Completed" : "Draft",
    });
  }

  await updateProjectCounts(projectId, {
    sceneCount: template.starterScenes.length,
    assetCount: template.starterScenes.filter((s) => Boolean(s.mediaUrl)).length,
    thumbnailUrl: template.thumbnailUrl,
  });

  return projectId;
}

export async function updateProjectMeta(
  projectId: string,
  patch: {
    title?: string;
    synopsis?: string;
    genre?: string;
    visualStyle?: string;
    aspectRatio?: AspectRatio;
    thumbnailUrl?: string;
  }
): Promise<void> {
  const path = `projects/${projectId}`;
  try {
    const clean: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (patch.title !== undefined) clean.title = clampStr(patch.title.trim() || "Untitled", 120);
    if (patch.synopsis !== undefined) clean.synopsis = clampStr(patch.synopsis, 2000);
    if (patch.genre !== undefined) clean.genre = clampStr(patch.genre, 60);
    if (patch.visualStyle !== undefined) clean.visualStyle = clampStr(patch.visualStyle, 80);
    if (patch.aspectRatio !== undefined) clean.aspectRatio = patch.aspectRatio;
    if (patch.thumbnailUrl !== undefined) clean.thumbnailUrl = clampStr(patch.thumbnailUrl, 1024);
    await updateDoc(doc(db, "projects", projectId), clean);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function updateProjectCounts(
  projectId: string,
  counts: { sceneCount?: number; assetCount?: number; thumbnailUrl?: string }
): Promise<void> {
  const path = `projects/${projectId}`;
  try {
    const clean: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (counts.sceneCount !== undefined) clean.sceneCount = Math.max(0, counts.sceneCount);
    if (counts.assetCount !== undefined) clean.assetCount = Math.max(0, counts.assetCount);
    if (counts.thumbnailUrl !== undefined) clean.thumbnailUrl = clampStr(counts.thumbnailUrl, 1024);
    await updateDoc(doc(db, "projects", projectId), clean);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function deleteProject(projectId: string): Promise<void> {
  const path = `projects/${projectId}`;
  try {
    await deleteDoc(doc(db, "projects", projectId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// ==========================================
// Characters, Objects & Locations Consistency Bible
// ==========================================

export function subscribeToCharacters(
  projectId: string,
  ownerId: string,
  onData: (chars: CharacterEntity[]) => void
): Unsubscribe {
  const path = `projects/${projectId}/characters`;
  const q = query(
    collection(db, "projects", projectId, "characters"),
    where("ownerId", "==", ownerId),
    orderBy("createdAt", "desc")
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => d.data() as CharacterEntity));
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export async function createCharacter(params: {
  projectId: string;
  ownerId: string;
  name: string;
  entityType: "character" | "object" | "location";
  appearancePrompt: string;
  referenceImageUrl?: string;
  tags?: string[];
}): Promise<string> {
  const id = makeId("char");
  const path = `projects/${params.projectId}/characters/${id}`;
  try {
    await setDoc(doc(db, "projects", params.projectId, "characters", id), {
      id,
      projectId: params.projectId,
      ownerId: params.ownerId,
      name: clampStr(params.name.trim() || "Unnamed Subject", 80),
      entityType: params.entityType,
      appearancePrompt: clampStr(params.appearancePrompt.trim() || "Visual reference subject", 1500),
      referenceImageUrl: clampStr(params.referenceImageUrl || "", 1024),
      tags: (params.tags || []).slice(0, 6).map((t) => clampStr(String(t), 30)),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function updateCharacter(
  projectId: string,
  characterId: string,
  patch: Partial<Pick<CharacterEntity, "name" | "entityType" | "appearancePrompt" | "referenceImageUrl" | "tags">>
): Promise<void> {
  const path = `projects/${projectId}/characters/${characterId}`;
  try {
    const clean: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (patch.name !== undefined) clean.name = clampStr(patch.name.trim() || "Subject", 80);
    if (patch.entityType !== undefined) clean.entityType = patch.entityType;
    if (patch.appearancePrompt !== undefined) clean.appearancePrompt = clampStr(patch.appearancePrompt, 1500);
    if (patch.referenceImageUrl !== undefined) clean.referenceImageUrl = clampStr(patch.referenceImageUrl, 1024);
    if (patch.tags !== undefined) clean.tags = patch.tags.slice(0, 6).map((t) => clampStr(String(t), 30));
    await updateDoc(doc(db, "projects", projectId, "characters", characterId), clean);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function deleteCharacter(projectId: string, characterId: string): Promise<void> {
  const path = `projects/${projectId}/characters/${characterId}`;
  try {
    await deleteDoc(doc(db, "projects", projectId, "characters", characterId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// ==========================================
// Media Assets (Uploaded & Generated)
// ==========================================

export function subscribeToAssets(
  projectId: string,
  ownerId: string,
  onData: (assets: MediaAsset[]) => void
): Unsubscribe {
  const path = `projects/${projectId}/assets`;
  const q = query(
    collection(db, "projects", projectId, "assets"),
    where("ownerId", "==", ownerId),
    orderBy("createdAt", "desc")
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => d.data() as MediaAsset));
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export async function createAsset(params: {
  projectId: string;
  ownerId: string;
  title: string;
  assetType: "image" | "video";
  source: "upload" | "generated";
  url?: string;
  mimeType?: string;
  prompt?: string;
  generationMode: GenerationMode;
  aspectRatio?: string;
  duration?: string;
  resolution?: string;
  cameraMovement?: string;
  visualStyle?: string;
  characterIds?: string[];
  interactionId?: string;
  status: PipelineStatus;
  creditCost: number;
}): Promise<string> {
  const id = makeId("ast");
  const path = `projects/${params.projectId}/assets/${id}`;
  try {
    await setDoc(doc(db, "projects", params.projectId, "assets", id), {
      id,
      projectId: params.projectId,
      ownerId: params.ownerId,
      title: clampStr(params.title.trim() || "Untitled Asset", 140),
      assetType: params.assetType,
      source: params.source,
      url: clampStr(params.url || "", 1024),
      mimeType: clampStr(params.mimeType || "", 100),
      prompt: clampStr(params.prompt || "", 3000),
      generationMode: params.generationMode,
      aspectRatio: params.aspectRatio || "16:9",
      duration: clampStr(params.duration || "", 16),
      resolution: clampStr(params.resolution || "", 16),
      cameraMovement: clampStr(params.cameraMovement || "", 80),
      visualStyle: clampStr(params.visualStyle || "", 80),
      characterIds: (params.characterIds || []).slice(0, 6),
      interactionId: clampStr(params.interactionId || "", 256),
      status: params.status,
      errorMessage: "",
      creditCost: Math.max(0, Math.min(500, Math.round(params.creditCost))),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function updateAssetStatus(
  projectId: string,
  assetId: string,
  patch: {
    status: PipelineStatus;
    url?: string;
    mimeType?: string;
    interactionId?: string;
    errorMessage?: string;
  }
): Promise<void> {
  const path = `projects/${projectId}/assets/${assetId}`;
  try {
    const clean: Record<string, unknown> = {
      status: patch.status,
      updatedAt: serverTimestamp(),
    };
    if (patch.url !== undefined) clean.url = clampStr(patch.url, 1024);
    if (patch.mimeType !== undefined) clean.mimeType = clampStr(patch.mimeType, 100);
    if (patch.interactionId !== undefined) clean.interactionId = clampStr(patch.interactionId, 256);
    if (patch.errorMessage !== undefined) clean.errorMessage = clampStr(patch.errorMessage, 1000);
    await updateDoc(doc(db, "projects", projectId, "assets", assetId), clean);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function deleteAsset(projectId: string, assetId: string): Promise<void> {
  const path = `projects/${projectId}/assets/${assetId}`;
  try {
    await deleteDoc(doc(db, "projects", projectId, "assets", assetId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

// ==========================================
// Storyboard Scenes
// ==========================================

export function subscribeToScenes(
  projectId: string,
  ownerId: string,
  onData: (scenes: StoryboardScene[]) => void
): Unsubscribe {
  const path = `projects/${projectId}/scenes`;
  const q = query(
    collection(db, "projects", projectId, "scenes"),
    where("ownerId", "==", ownerId),
    orderBy("orderIndex", "asc")
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => d.data() as StoryboardScene));
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export async function createScene(params: {
  projectId: string;
  ownerId: string;
  orderIndex: number;
  title: string;
  prompt: string;
  notes?: string;
  mediaUrl?: string;
  mediaType?: "image" | "video" | "none";
  assetId?: string;
  durationSeconds?: number;
  cameraMovement?: string;
  visualStyle?: string;
  characterIds?: string[];
  status?: SceneStatus;
}): Promise<string> {
  const id = makeId("scn");
  const path = `projects/${params.projectId}/scenes/${id}`;
  try {
    await setDoc(doc(db, "projects", params.projectId, "scenes", id), {
      id,
      projectId: params.projectId,
      ownerId: params.ownerId,
      orderIndex: Math.max(0, Math.round(params.orderIndex)),
      title: clampStr(params.title.trim() || "Untitled Scene", 140),
      prompt: clampStr(params.prompt || "", 3000),
      notes: clampStr(params.notes || "", 1500),
      mediaUrl: clampStr(params.mediaUrl || "", 1024),
      mediaType: params.mediaType || "none",
      assetId: clampStr(params.assetId || "", 128),
      durationSeconds: Math.max(1, Math.min(60, Math.round(params.durationSeconds || 8))),
      cameraMovement: clampStr(params.cameraMovement || "Static Locked", 80),
      visualStyle: clampStr(params.visualStyle || "Anamorphic 35mm", 80),
      characterIds: (params.characterIds || []).slice(0, 6),
      status: params.status || "Draft",
      errorMessage: "",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function updateSceneDetails(
  projectId: string,
  sceneId: string,
  patch: Partial<
    Pick<
      StoryboardScene,
      | "orderIndex"
      | "title"
      | "prompt"
      | "notes"
      | "durationSeconds"
      | "cameraMovement"
      | "visualStyle"
      | "characterIds"
      | "status"
      | "errorMessage"
    >
  >
): Promise<void> {
  const path = `projects/${projectId}/scenes/${sceneId}`;
  try {
    const clean: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (patch.orderIndex !== undefined) clean.orderIndex = Math.max(0, Math.round(patch.orderIndex));
    if (patch.title !== undefined) clean.title = clampStr(patch.title.trim() || "Scene", 140);
    if (patch.prompt !== undefined) clean.prompt = clampStr(patch.prompt, 3000);
    if (patch.notes !== undefined) clean.notes = clampStr(patch.notes, 1500);
    if (patch.durationSeconds !== undefined) {
      clean.durationSeconds = Math.max(1, Math.min(60, Math.round(patch.durationSeconds)));
    }
    if (patch.cameraMovement !== undefined) clean.cameraMovement = clampStr(patch.cameraMovement, 80);
    if (patch.visualStyle !== undefined) clean.visualStyle = clampStr(patch.visualStyle, 80);
    if (patch.characterIds !== undefined) clean.characterIds = patch.characterIds.slice(0, 6);
    if (patch.status !== undefined) clean.status = patch.status;
    if (patch.errorMessage !== undefined) clean.errorMessage = clampStr(patch.errorMessage, 1000);
    await updateDoc(doc(db, "projects", projectId, "scenes", sceneId), clean);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function updateSceneMedia(
  projectId: string,
  sceneId: string,
  patch: {
    mediaUrl: string;
    mediaType: "image" | "video" | "none";
    assetId: string;
    status: SceneStatus;
    errorMessage?: string;
  }
): Promise<void> {
  const path = `projects/${projectId}/scenes/${sceneId}`;
  try {
    await updateDoc(doc(db, "projects", projectId, "scenes", sceneId), {
      mediaUrl: clampStr(patch.mediaUrl, 1024),
      mediaType: patch.mediaType,
      assetId: clampStr(patch.assetId, 128),
      status: patch.status,
      errorMessage: clampStr(patch.errorMessage || "", 1000),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function deleteScene(projectId: string, sceneId: string): Promise<void> {
  const path = `projects/${projectId}/scenes/${sceneId}`;
  try {
    await deleteDoc(doc(db, "projects", projectId, "scenes", sceneId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function swapSceneOrder(
  projectId: string,
  sceneA: StoryboardScene,
  sceneB: StoryboardScene
): Promise<void> {
  const path = `projects/${projectId}/scenes`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, "projects", projectId, "scenes", sceneA.id), {
      orderIndex: sceneB.orderIndex,
      updatedAt: serverTimestamp(),
    });
    batch.update(doc(db, "projects", projectId, "scenes", sceneB.id), {
      orderIndex: sceneA.orderIndex,
      updatedAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

// ==========================================
// Scene Builder Timeline Clips
// ==========================================

export function subscribeToTimeline(
  projectId: string,
  ownerId: string,
  onData: (clips: TimelineClip[]) => void
): Unsubscribe {
  const path = `projects/${projectId}/timeline`;
  const q = query(
    collection(db, "projects", projectId, "timeline"),
    where("ownerId", "==", ownerId),
    orderBy("orderIndex", "asc")
  );
  return onSnapshot(
    q,
    (snap) => {
      onData(snap.docs.map((d) => d.data() as TimelineClip));
    },
    (err) => {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  );
}

export async function addTimelineClip(params: {
  projectId: string;
  ownerId: string;
  sceneId?: string;
  assetId?: string;
  title: string;
  mediaUrl: string;
  mediaType: "image" | "video";
  orderIndex: number;
  sourceDuration: number;
  transition?: TransitionType;
}): Promise<string> {
  const id = makeId("clp");
  const path = `projects/${params.projectId}/timeline/${id}`;
  const safeDur = Math.max(1, Math.min(120, Number(params.sourceDuration || 8)));
  try {
    await setDoc(doc(db, "projects", params.projectId, "timeline", id), {
      id,
      projectId: params.projectId,
      ownerId: params.ownerId,
      sceneId: clampStr(params.sceneId || "", 128),
      assetId: clampStr(params.assetId || "", 128),
      title: clampStr(params.title.trim() || "Clip", 140),
      mediaUrl: clampStr(params.mediaUrl, 1024),
      mediaType: params.mediaType,
      orderIndex: Math.max(0, Math.round(params.orderIndex)),
      sourceDuration: safeDur,
      trimStart: 0,
      trimEnd: safeDur,
      transition: params.transition || "cut",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function updateTimelineClip(
  projectId: string,
  clipId: string,
  patch: Partial<Pick<TimelineClip, "orderIndex" | "trimStart" | "trimEnd" | "transition" | "title">>
): Promise<void> {
  const path = `projects/${projectId}/timeline/${clipId}`;
  try {
    const clean: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (patch.orderIndex !== undefined) clean.orderIndex = Math.max(0, Math.round(patch.orderIndex));
    if (patch.trimStart !== undefined) clean.trimStart = Math.max(0, Number(patch.trimStart));
    if (patch.trimEnd !== undefined) clean.trimEnd = Math.max(0.5, Number(patch.trimEnd));
    if (patch.transition !== undefined) clean.transition = patch.transition;
    if (patch.title !== undefined) clean.title = clampStr(patch.title.trim() || "Clip", 140);
    await updateDoc(doc(db, "projects", projectId, "timeline", clipId), clean);
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function deleteTimelineClip(projectId: string, clipId: string): Promise<void> {
  const path = `projects/${projectId}/timeline/${clipId}`;
  try {
    await deleteDoc(doc(db, "projects", projectId, "timeline", clipId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function swapTimelineClipOrder(
  projectId: string,
  clipA: TimelineClip,
  clipB: TimelineClip
): Promise<void> {
  const path = `projects/${projectId}/timeline`;
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, "projects", projectId, "timeline", clipA.id), {
      orderIndex: clipB.orderIndex,
      updatedAt: serverTimestamp(),
    });
    batch.update(doc(db, "projects", projectId, "timeline", clipB.id), {
      orderIndex: clipA.orderIndex,
      updatedAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}
