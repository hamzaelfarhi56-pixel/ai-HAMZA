export type AspectRatio = "16:9" | "9:16" | "1:1" | "4:3";
export type GenerationMode =
  | "text-to-video"
  | "image-to-video"
  | "keyframe-motion"
  | "video-edit"
  | "text-to-image"
  | "image-edit"
  | "upload";

export type PipelineStatus = "Generating" | "Processing" | "Completed" | "Failed";
export type SceneStatus = "Draft" | PipelineStatus;
export type TransitionType = "cut" | "crossfade" | "dip-to-black";

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  credits: number;
  totalGenerated: number;
  defaultAspectRatio?: AspectRatio;
  defaultStyle?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface StudioProject {
  id: string;
  ownerId: string;
  title: string;
  synopsis?: string;
  genre?: string;
  visualStyle: string;
  aspectRatio: AspectRatio;
  thumbnailUrl?: string;
  sceneCount: number;
  assetCount: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface CharacterEntity {
  id: string;
  projectId: string;
  ownerId: string;
  name: string;
  entityType: "character" | "object" | "location";
  appearancePrompt: string;
  referenceImageUrl?: string;
  tags?: string[];
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface MediaAsset {
  id: string;
  projectId: string;
  ownerId: string;
  title: string;
  assetType: "image" | "video";
  source: "upload" | "generated";
  url?: string;
  mimeType?: string;
  prompt?: string;
  generationMode: GenerationMode;
  aspectRatio?: string;
  duration?: string;
  resolution?: string;
  cameraMovement?: string;
  visualStyle?: string;
  characterIds?: string[];
  interactionId?: string;
  status: PipelineStatus;
  errorMessage?: string;
  creditCost: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface StoryboardScene {
  id: string;
  projectId: string;
  ownerId: string;
  orderIndex: number;
  title: string;
  prompt: string;
  notes?: string;
  mediaUrl?: string;
  mediaType: "image" | "video" | "none";
  assetId?: string;
  durationSeconds: number;
  cameraMovement?: string;
  visualStyle?: string;
  characterIds?: string[];
  status: SceneStatus;
  errorMessage?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface TimelineClip {
  id: string;
  projectId: string;
  ownerId: string;
  sceneId?: string;
  assetId?: string;
  title: string;
  mediaUrl: string;
  mediaType: "image" | "video";
  orderIndex: number;
  sourceDuration: number;
  trimStart: number;
  trimEnd: number;
  transition: TransitionType;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export const VISUAL_STYLES = [
  "Anamorphic 35mm",
  "Neo-Noir Rain",
  "IMAX Documentary",
  "Analog 16mm Grain",
  "Architectural Minimal",
  "Stylized Studio Animation",
  "High-Contrast Editorial",
] as const;

export const CAMERA_MOVEMENTS = [
  "Static Locked",
  "Slow Dolly In",
  "Pull Back Reveal",
  "Tracking Steadicam",
  "Orbital Arc",
  "Crane Ascent",
  "Handheld Documentary",
  "Low-Angle Push",
] as const;

export const VIDEO_RESOLUTIONS = ["360p", "720p", "1080p", "4K"] as const;
export const IMAGE_RESOLUTIONS = ["1K", "2K", "4K"] as const;

export const CREDIT_COSTS = {
  imageStandard: 4,
  imageHighRes: 8,
  videoBase: 12,
  videoPerSecond: 1,
  video4kMultiplier: 2,
  assistantAction: 0,
};

export function calculateGenerationCreditCost(params: {
  kind: "image" | "video";
  resolution: string;
  durationSeconds?: number;
}): number {
  if (params.kind === "image") {
    return params.resolution === "2K" || params.resolution === "4K"
      ? CREDIT_COSTS.imageHighRes
      : CREDIT_COSTS.imageStandard;
  }
  const dur = Math.max(3, Math.min(15, params.durationSeconds || 8));
  const base = CREDIT_COSTS.videoBase + Math.max(0, dur - 5) * CREDIT_COSTS.videoPerSecond;
  return params.resolution === "4K" || params.resolution === "4k"
    ? base * CREDIT_COSTS.video4kMultiplier
    : base;
}

export interface ShowcaseTemplate {
  id: string;
  title: string;
  genre: string;
  visualStyle: string;
  aspectRatio: AspectRatio;
  synopsis: string;
  thumbnailUrl: string;
  starterCharacters: Array<{
    name: string;
    entityType: "character" | "object" | "location";
    appearancePrompt: string;
    referenceImageUrl?: string;
    tags: string[];
  }>;
  starterScenes: Array<{
    title: string;
    prompt: string;
    notes: string;
    cameraMovement: string;
    durationSeconds: number;
    mediaUrl?: string;
    mediaType: "image" | "video" | "none";
  }>;
}

export const SHOWCASE_TEMPLATES: ShowcaseTemplate[] = [
  {
    id: "noir-rain",
    title: "Meridian Rain",
    genre: "Neo-Noir Thriller",
    visualStyle: "Neo-Noir Rain",
    aspectRatio: "16:9",
    synopsis:
      "A lone archivist walks the sodium-lit backstreets of Lower Meridian at 2:00 AM, searching for an unindexed watchmaker before dawn.",
    thumbnailUrl: "/src/assets/images/studio_scifi_noir_1795353163965.jpg",
    starterCharacters: [
      {
        name: "Kael Mercer",
        entityType: "character",
        appearancePrompt:
          "40-year-old investigator in a structured charcoal herringbone wool trench coat, dark collared shirt, subtle facial stubble, focused eyes, warm amber rim lighting.",
        referenceImageUrl: "/src/assets/images/character_protagonist_ref_1795353165041.jpg",
        tags: ["protagonist", "noir", "coat"],
      },
    ],
    starterScenes: [
      {
        title: "Establishing Alleyway",
        prompt:
          "Rain-slicked cobblestone street at night illuminated by warm amber sodium lamps, a lone figure in a charcoal trench coat walking away into mist, anamorphic 35mm.",
        notes: "Opening atmosphere establisher, keep reflections crisp.",
        cameraMovement: "Slow Dolly In",
        durationSeconds: 8,
        mediaUrl: "/src/assets/images/studio_scifi_noir_1795353163965.jpg",
        mediaType: "image",
      },
      {
        title: "The Watchmaker's Bench",
        prompt:
          "Close-up inside a quiet watchmaker atelier under a warm brass desk lamp, intricate brass gears and leather tools arranged on dark walnut wood.",
        notes: "Cut in after alley door opens.",
        cameraMovement: "Tracking Steadicam",
        durationSeconds: 6,
        mediaUrl: "/src/assets/images/studio_atelier_craft_1795353163876.jpg",
        mediaType: "image",
      },
    ],
  },
  {
    id: "alpine-ascent",
    title: "Above the Cloudline",
    genre: "Expedition Documentary",
    visualStyle: "IMAX Documentary",
    aspectRatio: "16:9",
    synopsis:
      "An aerial and ground-level chronicle following a two-person survey team crossing the high granite ridges at first light.",
    thumbnailUrl: "/src/assets/images/studio_alpine_expedition_1795353164023.jpg",
    starterCharacters: [
      {
        name: "North Ridge Massif",
        entityType: "location",
        appearancePrompt:
          "Jagged basalt and snow-covered alpine ridgeline piercing a dense sea of low valley clouds at golden hour, warm amber alpenglow on west faces.",
        referenceImageUrl: "/src/assets/images/studio_alpine_expedition_1795353164023.jpg",
        tags: ["location", "alpine", "golden-hour"],
      },
    ],
    starterScenes: [
      {
        title: "Sunrise Over the Sea of Clouds",
        prompt:
          "Sweeping aerial glide over jagged snow-capped peaks emerging from valley mist, golden hour rim light across basalt ridges, IMAX 65mm clarity.",
        notes: "Hero aerial opener.",
        cameraMovement: "Crane Ascent",
        durationSeconds: 10,
        mediaUrl: "/src/assets/images/studio_alpine_expedition_1795353164023.jpg",
        mediaType: "image",
      },
    ],
  },
  {
    id: "atelier-chronicle",
    title: "The Brass Escapement",
    genre: "Artisan Portrait",
    visualStyle: "Analog 16mm Grain",
    aspectRatio: "16:9",
    synopsis:
      "An intimate study of mechanical precision, patience, and hand-turned brass inside a century-old horology workshop.",
    thumbnailUrl: "/src/assets/images/studio_atelier_craft_1795353163876.jpg",
    starterCharacters: [
      {
        name: "Brass Pocket Movement",
        entityType: "object",
        appearancePrompt:
          "Exposed vintage brass pocket-watch escapement with blued steel screws and engraved balance cock resting on oiled leather under warm tungsten light.",
        referenceImageUrl: "/src/assets/images/studio_atelier_craft_1795353163876.jpg",
        tags: ["prop", "brass", "macro"],
      },
    ],
    starterScenes: [
      {
        title: "Calibrating the Balance Wheel",
        prompt:
          "Master watchmaker leaning over a brass lamp-lit oak workbench adjusting miniature brass gears with fine steel tweezers, shallow 35mm depth of field.",
        notes: "Warm tungsten contrast against dark workshop background.",
        cameraMovement: "Slow Dolly In",
        durationSeconds: 8,
        mediaUrl: "/src/assets/images/studio_atelier_craft_1795353163876.jpg",
        mediaType: "image",
      },
    ],
  },
];
