/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from "react";
import { onAuthStateChanged, signInWithPopup, signOut, type User } from "firebase/auth";
import { MotionConfig, motion } from "motion/react";
import { auth, googleProvider } from "./firebase";
import {
  addStudioCredits,
  createProject,
  createProjectFromTemplate,
  deleteProject,
  ensureUserProfile,
  subscribeToAssets,
  subscribeToCharacters,
  subscribeToProject,
  subscribeToProjects,
  subscribeToScenes,
  subscribeToTimeline,
  subscribeToUserProfile,
  updateUserSettings,
} from "./services/firestoreService";
import type {
  AspectRatio,
  CharacterEntity,
  MediaAsset,
  ShowcaseTemplate,
  StoryboardScene,
  StudioProject,
  TimelineClip,
  UserProfile,
} from "./types/studio";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { Header, type StudioView } from "./components/Header";
import { HomePage } from "./components/HomePage";
import { WorkspaceGenerator } from "./components/WorkspaceGenerator";
import { CharacterBible } from "./components/CharacterBible";
import { StoryboardView } from "./components/StoryboardView";
import { SceneBuilderTimeline } from "./components/SceneBuilderTimeline";
import { AiAssistantDrawer } from "./components/AiAssistantDrawer";

function StudioShell() {
  const [authReady, setAuthReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  const [projects, setProjects] = useState<StudioProject[]>([]);
  const [loadingProjects, setLoadingProjects] = useState(false);

  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [activeProject, setActiveProject] = useState<StudioProject | null>(null);
  const [characters, setCharacters] = useState<CharacterEntity[]>([]);
  const [assets, setAssets] = useState<MediaAsset[]>([]);
  const [scenes, setScenes] = useState<StoryboardScene[]>([]);
  const [timelineClips, setTimelineClips] = useState<TimelineClip[]>([]);

  const [activeView, setActiveView] = useState<StudioView>("home");
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [draftPrompt, setDraftPrompt] = useState<string | undefined>(undefined);
  const [preselectedCharIds, setPreselectedCharIds] = useState<string[]>([]);

  // Auth Listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      setAuthReady(true);
      if (nextUser) {
        try {
          await ensureUserProfile(nextUser);
        } catch (err) {
          setAuthError(err instanceof Error ? err.message : "Failed to initialize user profile.");
        }
      } else {
        setProfile(null);
        setProjects([]);
        setActiveProjectId(null);
        setActiveProject(null);
        setActiveView("home");
      }
    });
    return () => unsub();
  }, []);

  // User Profile & Projects Subscriptions (only when signed in)
  useEffect(() => {
    if (!authReady || !user) return;
    setLoadingProjects(true);
    const unsubProfile = subscribeToUserProfile(user.uid, (p) => {
      setProfile(p);
    });
    const unsubProjects = subscribeToProjects(user.uid, (list) => {
      setProjects(list);
      setLoadingProjects(false);
    });
    return () => {
      unsubProfile();
      unsubProjects();
    };
  }, [authReady, user]);

  // Active Project Subcollections Subscriptions
  useEffect(() => {
    if (!authReady || !user || !activeProjectId) {
      setActiveProject(null);
      setCharacters([]);
      setAssets([]);
      setScenes([]);
      setTimelineClips([]);
      return;
    }

    const unsubProj = subscribeToProject(activeProjectId, (proj) => {
      setActiveProject(proj);
      if (!proj) {
        setActiveProjectId(null);
        setActiveView("home");
      }
    });
    const unsubChars = subscribeToCharacters(activeProjectId, user.uid, setCharacters);
    const unsubAssets = subscribeToAssets(activeProjectId, user.uid, setAssets);
    const unsubScenes = subscribeToScenes(activeProjectId, user.uid, setScenes);
    const unsubTimeline = subscribeToTimeline(activeProjectId, user.uid, setTimelineClips);

    return () => {
      unsubProj();
      unsubChars();
      unsubAssets();
      unsubScenes();
      unsubTimeline();
    };
  }, [authReady, user, activeProjectId]);

  async function handleSignIn() {
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setAuthError(
        err instanceof Error ? err.message : "Sign-in was cancelled or blocked by popup policy."
      );
    }
  }

  async function handleSignOut() {
    setAssistantOpen(false);
    await signOut(auth);
  }

  async function handleOpenProject(projectId: string) {
    setActiveProjectId(projectId);
    setActiveView("workspace");
  }

  async function handleCreateProject(data: {
    title: string;
    synopsis: string;
    genre: string;
    visualStyle: string;
    aspectRatio: AspectRatio;
  }) {
    if (!user) return;
    const id = await createProject({
      ownerId: user.uid,
      ...data,
    });
    setActiveProjectId(id);
    setActiveView("workspace");
  }

  async function handleCreateFromTemplate(template: ShowcaseTemplate) {
    if (!user) return;
    const id = await createProjectFromTemplate(user.uid, template);
    setActiveProjectId(id);
    setActiveView("workspace");
  }

  async function handleDeleteProject(projectId: string) {
    if (activeProjectId === projectId) {
      setActiveProjectId(null);
      setActiveView("home");
    }
    await deleteProject(projectId);
  }

  function handleNavigate(view: StudioView) {
    if (view === "home") {
      setActiveView("home");
      return;
    }
    if (!activeProjectId) {
      setActiveView("home");
      return;
    }
    setActiveView(view);
  }

  if (!authReady) {
    return (
      <div className="min-h-screen bg-[#0B0D10] text-[#F2F4F8] flex items-center justify-center">
        <div className="text-xs text-neutral-400 font-mono">Loading KinoFrame Studio...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0B0D10] text-[#F2F4F8] flex flex-col">
      <Header
        user={user}
        profile={profile}
        activeView={activeView}
        hasActiveProject={Boolean(activeProject)}
        onNavigate={handleNavigate}
        onSignIn={() => void handleSignIn()}
        onSignOut={() => void handleSignOut()}
        onAddCredits={() => {
          if (user) void addStudioCredits(user.uid, 150);
        }}
        onUpdateDefaults={(aspectRatio, style) => {
          if (user) {
            void updateUserSettings(user.uid, {
              defaultAspectRatio: aspectRatio,
              defaultStyle: style,
            });
          }
        }}
        onToggleAssistant={() => setAssistantOpen((v) => !v)}
      />

      {authError && (
        <div className="max-w-[1440px] mx-auto w-full px-4 sm:px-6 pt-4">
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-300 flex items-center justify-between gap-4">
            <span>{authError}</span>
            <button
              type="button"
              onClick={() => setAuthError(null)}
              className="underline hover:text-white cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      <div className="flex-1">
        <motion.div
          key={`${activeView}_${activeProjectId || "home"}`}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
        >
          {activeView === "home" || !activeProject || !user ? (
            <HomePage
              user={user}
              profile={profile}
              projects={projects}
              loadingProjects={loadingProjects}
              onSignIn={() => void handleSignIn()}
              onOpenProject={(id) => void handleOpenProject(id)}
              onCreateProject={handleCreateProject}
              onCreateFromTemplate={handleCreateFromTemplate}
              onDeleteProject={handleDeleteProject}
            />
          ) : activeView === "workspace" ? (
            <WorkspaceGenerator
              uid={user.uid}
              project={activeProject}
              credits={profile?.credits ?? 0}
              characters={characters}
              assets={assets}
              sceneCount={scenes.length}
              timelineCount={timelineClips.length}
              draftPromptFromAssistant={draftPrompt}
              preselectedCharIds={preselectedCharIds}
              onClearDraftPrompt={() => setDraftPrompt(undefined)}
              onGoToCharacters={() => setActiveView("characters")}
              onGoToStoryboard={() => setActiveView("storyboard")}
              onGoToTimeline={() => setActiveView("timeline")}
            />
          ) : activeView === "characters" ? (
            <CharacterBible
              uid={user.uid}
              project={activeProject}
              credits={profile?.credits ?? 0}
              characters={characters}
              onUseCharacterInWorkspace={(charId) => {
                setPreselectedCharIds((prev) =>
                  prev.includes(charId) ? prev : [...prev.slice(0, 5), charId]
                );
                setActiveView("workspace");
              }}
            />
          ) : activeView === "storyboard" ? (
            <StoryboardView
              uid={user.uid}
              project={activeProject}
              credits={profile?.credits ?? 0}
              scenes={scenes}
              characters={characters}
              assets={assets}
              timelineCount={timelineClips.length}
              onGoToTimeline={() => setActiveView("timeline")}
            />
          ) : (
            <SceneBuilderTimeline
              uid={user.uid}
              project={activeProject}
              clips={timelineClips}
              scenes={scenes}
              assets={assets}
            />
          )}
        </motion.div>
      </div>

      {activeProject && (
        <AiAssistantDrawer
          open={assistantOpen}
          project={activeProject}
          characters={characters}
          scenes={scenes}
          onClose={() => setAssistantOpen(false)}
          onUseAsPrompt={(text) => {
            setDraftPrompt(text);
            setActiveView("workspace");
          }}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <MotionConfig reducedMotion="user">
        <StudioShell />
      </MotionConfig>
    </ErrorBoundary>
  );
}
